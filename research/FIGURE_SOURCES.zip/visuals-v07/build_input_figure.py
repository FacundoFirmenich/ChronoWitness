"""Analytical acquisition weights; dimensionless, no empirical calibration."""
from pathlib import Path
import csv,hashlib,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'axes.edgecolor':'#263C68','xtick.color':'#263C68','ytick.color':'#263C68','grid.color':'#E1DDEF','axes.prop_cycle':matplotlib.cycler(color=['#356FA8','#7364B5','#B94C8C','#86A6D3'])})
R=Path(__file__).resolve().parents[1];OUT=R/'figures-v07'
report=json.loads((R/'results/INPUT_ROBUSTNESS.json').read_text());assert report['status']=='PASS_EXACT_INPUT_ROBUSTNESS'
s=np.linspace(0,3,601);lo=np.maximum(2-s,0);hi=3-s
fig,axes=plt.subplots(2,1,figsize=(7.4,6.4),layout='constrained');rows=[]
for q,color in [(1.,'#226eae'),(3.,'#B94C8C')]:
    single=(np.exp(-q*lo)-np.exp(-q*hi))/q
    cascade=((1+q*lo)*np.exp(-q*lo)-(1+q*hi)*np.exp(-q*hi))/q**2
    axes[0].plot(s,single,color=color,label=f'Contraction rate {q:g}')
    axes[1].plot(s,cascade,color=color,label=f'Both contraction rates {q:g}')
    rows.extend(zip(np.full_like(s,q),s,single,cascade))
for ax in axes:
    ax.axvspan(2,3,color='#7364B5',alpha=.10);ax.axvline(2,color='#526477',ls='--',lw=1)
    ax.set_xlim(0,3);ax.set_ylim(bottom=0);ax.set_xlabel('Time of delivery error (dimensionless)');ax.legend(fontsize=9)
axes[0].set_title('A  Promoter error weight for corrected output',loc='left',weight='bold');axes[0].set_ylabel(r'$K_q(s)$')
axes[1].set_title('B  Promoter error weight through an uncorrected reporter',loc='left',weight='bold');axes[1].set_ylabel(r'$K_{q,q}(s)$')
for ax in axes:ax.text(2.5,.97,'Measured window',ha='center',va='top',transform=ax.get_xaxis_transform(),fontsize=9,color='#7364B5')
for ext in ['pdf','svg','png']:fig.savefig(OUT/('FIG7_input_robustness.'+ext),bbox_inches='tight',dpi=400)
plt.close(fig)
with (OUT/'data/input_kernels.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['contraction_rate','error_time','corrected_kernel','raw_resonant_kernel']);w.writerows(rows)
manifest=json.loads((OUT/'FIGURE_PROVENANCE.json').read_text());manifest.update(figures=8,main_figures=5,supplementary_figures=3)
manifest['numerical_plotting_only']='Figures S3, 4 and 5 sample dimensionless analytical functions. No fitted biological rates or observations.'
for p in [Path(__file__),R/'results/INPUT_ROBUSTNESS.json']:manifest['inputs'][p.relative_to(R).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
for p in [*OUT.glob('FIG7_input_robustness.*'),OUT/'data/input_kernels.csv']:manifest['outputs'][p.relative_to(R).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(OUT/'FIGURE_PROVENANCE.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS: input-error kernel figure and provenance')

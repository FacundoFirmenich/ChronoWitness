"""Exact model quantities first, plotting floats only at the rendering boundary.
Run on the remote runner with matplotlib; no experimental observations generated.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
import csv,hashlib,json,sys,textwrap
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'axes.edgecolor':'#263C68','xtick.color':'#263C68','ytick.color':'#263C68','grid.color':'#E1DDEF','axes.prop_cycle':matplotlib.cycler(color=['#356FA8','#7364B5','#B94C8C','#86A6D3'])})
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
from graph_model import graph
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'analysis'))
from verify_phase_python import block,steady
OUT=ROOT/'figures-v07';OUT.mkdir(exist_ok=True)
GOUT=ROOT/'graph-v07';GOUT.mkdir(exist_ok=True)
DATA=OUT/'data';DATA.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,
    'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42,'axes.titleweight':'bold'})
blue='#226eae';red='#B94C8C';teal='#7364B5';gray='#546375'
pair=json.loads((ROOT/'sources/FD7_CERTIFICATE_v0.7.0.json').read_text())['pair']
a=tuple(map(int,pair['sequence_A']));b=tuple(map(int,pair['sequence_B']));assert len(a)==len(b)==24
def save(fig,name):
    for ext in ['pdf','svg','png']:fig.savefig(OUT/f'{name}.{ext}',bbox_inches='tight',dpi=400)
    plt.close(fig)
def csvwrite(name,header,rows):
    with (DATA/name).open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f);w.writerow(header);w.writerows(rows)
def counts(w,k):return Counter(tuple(w[(i+j)%24] for j in range(k)) for i in range(24))
l1=[]
for k in range(1,9):
    ca,cb=counts(a,k),counts(b,k);l1.append(sum(abs(ca[x]-cb[x]) for x in ca.keys()|cb.keys()))
assert l1==[0]*7+[8]
auto=lambda w:[sum((2*w[i]-1)*(2*w[(i+d)%24]-1) for i in range(24)) for d in range(24)]
ac,bc=auto(a),auto(b);assert ac==bc
csvwrite('design.csv',['position','A','B','lag','autocorrelation_A_numerator_over_24','autocorrelation_B_numerator_over_24'],[(i+1,a[i],b[i],i,ac[i],bc[i]) for i in range(24)])
csvwrite('cyclic_words.csv',['order','L1_count_difference'],list(enumerate(l1,1)))
fig=plt.figure(figsize=(7.2,4.6),layout='constrained');gs=fig.add_gridspec(2,2,height_ratios=[.7,1])
ax=fig.add_subplot(gs[0,:]);ax.imshow([a,b],cmap=matplotlib.colors.ListedColormap(['#e8edf2',blue]),vmin=0,vmax=1,aspect='auto')
ax.set_yticks([0,1],['A','B']);ax.set_xticks(range(0,24,2),range(1,25,2));ax.set_xlabel('Symbol position');ax.set_title('A  Exact periodic inputs',loc='left');ax.set_xticks(np.arange(-.5,24,1),minor=True);ax.grid(which='minor',color='white',lw=1);ax.tick_params(which='minor',bottom=False)
for y,w in enumerate([a,b]):
    for i,v in enumerate(w):ax.text(i,y,str(v),ha='center',va='center',color='white' if v else '#46596a',fontsize=7)
ax=fig.add_subplot(gs[1,0]);ax.bar(range(1,9),l1,color=[blue]*7+[red]);ax.scatter(range(1,8),[0]*7,color=blue,s=18,zorder=4);ax.set_xticks(range(1,9));ax.set_ylim(-.4,9.2);ax.set_xlabel('Cyclic word order');ax.set_ylabel('L1 count difference');ax.set_title('B  First difference at order 8',loc='left',fontsize=10)
ax=fig.add_subplot(gs[1,1]);ax.plot(range(24),np.array(ac)/24,color=blue,lw=2,label='A');ax.scatter(range(24),np.array(bc)/24,facecolors='none',edgecolors=red,s=30,label='B');ax.set_xlabel('Cyclic lag');ax.set_ylabel('Autocorrelation');ax.set_title('C  Coincident autocorrelations',loc='left',fontsize=10);ax.legend(frameon=False,ncol=2)
save(fig,'FIG1_design')

specs=[('Two-state phase-specific',2,(1,0,0,1),0,0),('Historical absorbing reader',4,(0,0,0,2,1,3,3,3),1,3),('Synchronizing witness',4,(0,1,0,2,1,3,2,1),1,3)]
fig,axes=plt.subplots(3,1,figsize=(7.2,6),layout='constrained',sharex=True);rows=[]
for ax,(title,m,delta,q0,readout) in zip(axes,specs):
    aa=[];bb=[]
    for phase in range(24):
        pa=steady(block(a[phase:]+a[:phase],delta,m),q0,m);pb=steady(block(b[phase:]+b[:phase],delta,m),q0,m)
        va=sum(pa[2*readout:2*readout+2])/24;vb=sum(pb[2*readout:2*readout+2])/24;aa.append(va);bb.append(vb)
        rows.append([title,m,str(delta),q0,readout,phase,str(va),str(vb),str(va-vb)])
    differences=[x-y for x,y in zip(aa,bb)];mean=sum(differences)/24
    if m==2 or delta==(0,0,0,2,1,3,3,3):assert mean==0
    else:assert set(differences)=={F(1,24)}
    ax.axhline(0,color='#9aa7b2',lw=.8);ax.plot(range(24),list(map(float,differences)),'.-',color=teal if mean else blue,lw=1.4)
    ax.axhline(float(mean),color=red,ls='--',lw=1,label=f'Phase mean = {mean}');ax.legend(frameon=False,loc='upper right',fontsize=8)
    ax.set_title(f'{title} | initial {q0}, readout state {readout}',loc='left',fontsize=10);ax.set_ylabel('Occupation A − B');ax.margins(y=.3)
axes[-1].set_xlabel('Common input phase');axes[-1].set_xticks(range(0,24,3));save(fig,'FIG2_phase')
csvwrite('phase_contrasts.csv',['reader','states','delta','initial','readout','phase','A','B','A_minus_B'],rows)

source=ROOT/'results/MARKOV_BOUNDARY.json';j=json.loads(source.read_text());w=j['three_state_witness'];d=list(map(F,w['contrasts']))
assert d==[F(x)-F(y) for x,y in zip(w['profile_A'],w['profile_B'])];assert sum(d[:2])==F(5,131072);assert sum(d)==0
def det3(m):return sum((1 if p in [(0,1,2),(1,2,0),(2,0,1)] else -1)*m[0][p[0]]*m[1][p[1]]*m[2][p[2]] for p in [(0,1,2),(0,2,1),(1,0,2),(1,2,0),(2,0,1),(2,1,0)])
dets=[det3([[F(v) for v in row] for row in mat]) for mat in w['matrices']];assert dets==[F(-1,4),F(0)]
csvwrite('markov_contrasts.csv',['state','symbol','A','B','A_minus_B'],[(i//2,i%2,w['profile_A'][i],w['profile_B'][i],str(d[i])) for i in range(6)])
csvwrite('markov_determinants.csv',['matrix','determinant'],list(zip(['P0','P1'],map(str,dets))))
fig=plt.figure(figsize=(7.2,5.5),layout='constrained');gs=fig.add_gridspec(2,2);ax=fig.add_subplot(gs[0,:]);ax.bar(range(6),[float(x)*1e5 for x in d],color=[blue if x>=0 else red for x in d]);ax.axhline(0,color=gray,lw=.7);ax.set_xticks(range(6),['(0,0)','(0,1)','(1,0)','(1,1)','(2,0)','(2,1)']);ax.set_xlabel('(state, symbol)');ax.set_ylabel('A − B  (×10⁻⁵)');ax.set_ylim(-8,11)
for i,x in enumerate(d):ax.text(i,float(x)*1e5+(.6 if x>=0 else -.6),str(x),ha='center',va='bottom' if x>=0 else 'top',fontsize=8)
ax.set_title('A  Exact three-state occupation contrasts',loc='left')
ax=fig.add_subplot(gs[1,0]);ax.axis('off');ax.set_title('B  State-0 total',loc='left');ax.text(.04,.65,'5/65536 − 5/131072\n= 5/131072',fontsize=15,transform=ax.transAxes,color=blue,linespacing=1.7);ax.text(.04,.12,'Specified witness; not an optimized\nor measured biological effect.',transform=ax.transAxes,fontsize=9)
ax=fig.add_subplot(gs[1,1]);ax.bar([0,1],list(map(float,dets)),color=[red,blue]);ax.scatter([1],[0],color=blue,zorder=3);ax.axhline(0,color=gray,lw=.8);ax.set_xticks([0,1],['det P₀ = −1/4','det P₁ = 0']);ax.set_ylim(-.31,.17);ax.set_title('C  Continuous-time boundary',loc='left',fontsize=10);ax.text(.5,.12,'Finite homogeneous CTMC:\ndet exp(QΔ) > 0',ha='center',fontsize=9);save(fig,'FIG3_markov')

fig,axes=plt.subplots(2,1,figsize=(7.2,5.1),layout='constrained',gridspec_kw={'height_ratios':[.8,1]});ax=axes[0];ax.axis('off');ax.set_xlim(-.02,1.02);ax.set_ylim(0,1);ax.set_title('A  Conditional transport of an exact equality',loc='left')
boxes=[('Qualified FD7\ndelivery',.01),('Two-state\npromoter integral',.35),('Common linear\nexpression mean',.69)]
for text,x in boxes:ax.add_patch(FancyBboxPatch((x,.43),.28,.32,boxstyle='round,pad=.015',facecolor='#edf4f9',edgecolor=blue));ax.text(x+.14,.59,text,ha='center',va='center',fontsize=10)
for x in [.30,.64]:ax.annotate('',xy=(x+.04,.59),xytext=(x,.59),arrowprops={'arrowstyle':'->','color':blue,'lw':1.8})
ax.text(.5,.14,'Equal interval duration · common parameters · periodic regime\nConstant degradation / stable time-independent linear cascade',ha='center',va='center',fontsize=9)
ax=axes[1];theta=np.geomspace(.001,10,301);rows=[]
for k,color in [(1,blue),(5,teal),(10,red)]:
    yy=np.exp(-k*theta);ax.semilogx(theta,yy,label=f'{k} period'+('s' if k!=1 else ''),color=color);rows.extend([[k,format(t,'.17g'),format(y,'.17g')] for t,y in zip(theta,yy)])
ax.set_xlabel('θ = 12 Δ (κ₀ + κ₁), dimensionless');ax.set_ylabel('Remaining initial difference / initial');ax.set_ylim(-.02,1.04);ax.legend(frameon=False);ax.set_title('B  Contraction approaches one as rates approach zero',loc='left',fontsize=10);save(fig,'FIG4_kinetic')
csvwrite('kinetic_contraction.csv',['periods','dimensionless_theta','exp_minus_k_theta'],rows)

g=graph();(GOUT/'epistemic_graph.json').write_text(json.dumps(g,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
html=(Path(__file__).parent/'graph_shell.html').read_text(encoding='utf-8').replace('__GRAPH_DATA__',json.dumps(g,ensure_ascii=False).replace('</','<\\/'))
(GOUT/'epistemic_graph.html').write_text(html,encoding='utf-8')
lines=['digraph ChronoWitness {','rankdir=LR;','node [shape=box];']
for n in g['nodes']:lines.append(json.dumps(n['id'])+' [label='+json.dumps(n['label'])+'];')
for e in g['edges']:lines.append(f'{json.dumps(e["source"])} -> {json.dumps(e["target"])} [label={json.dumps(e["kind"])}];')
(GOUT/'epistemic_graph.dot').write_text('\n'.join(lines+['}'])+'\n',encoding='utf-8')
colors={'exact':'#EAE4F5','conditional':'#B94C8C','adverse':'#F3DFEC','boundary':'#eee1f7','evidence':'#dbeaff','open':'#e7ebf1','separate':'#dceff4','context':'#e4edf8'}
byid={n['id']:n for n in g['nodes']}
main=[['fd7','phase','occupation','kineticclass'],['det4','markov3','kineticnull','reporternull'],['enum','poly','integration','cascade'],['phaseadverse','nonembed','nowashin','nobiology']]
pos={id:(col*2.1,row*1.5) for row,ids in enumerate(main) for col,id in enumerate(ids)}
fig,ax=plt.subplots(figsize=(7.3,6.2),layout='constrained');ax.set_xlim(-.1,8.3);ax.set_ylim(6.1,-.5);ax.axis('off')
projection=[('fd7','det4','contract'),('phase','det4','contract'),('occupation','markov3','contract'),('kineticclass','kineticnull','contract'),('kineticnull','reporternull','support'),('enum','det4','support'),('poly','markov3','support'),('integration','kineticnull','support'),('phaseadverse','det4','boundary'),('nonembed','markov3','boundary'),('nowashin','kineticnull','boundary'),('cascade','reporternull','boundary')]
patches={}
for id,(x,y) in pos.items():
    n=byid[id];patch=FancyBboxPatch((x,y),1.78,.73,boxstyle='round,pad=.04',facecolor=colors[n['status']],edgecolor=gray,lw=.7,zorder=2);ax.add_patch(patch);patches[id]=patch
    ax.text(x+.89,y+.30,textwrap.fill(n['label'],24),ha='center',va='center',fontsize=8,zorder=3);ax.text(x+.89,y+.62,n['status'].upper(),ha='center',fontsize=5.7,color=gray,zorder=3)
for src,dst,kind in projection:
    x,y=pos[src];u,v=pos[dst];ax.add_patch(FancyArrowPatch((x+.89,y+.36),(u+.89,v+.36),patchA=patches[src],patchB=patches[dst],arrowstyle='-|>',mutation_scale=9,linewidth=1.2,color=red if kind=='boundary' else blue if kind=='support' else gray,linestyle='--' if kind=='boundary' else '-',connectionstyle='arc3,rad=.10',shrinkA=4,shrinkB=4,zorder=1))
ax.text(0,-.28,'Inputs, results, evidence and preserved limitations',fontsize=9,color=gray)
ax.text(0,5.78,'Blue: support   Gray: required contract   Rose dashed: restriction / caveat\nProjection of the complete typed graph; arrows are not biological interactions.',fontsize=8,color=gray);save(fig,'FIG5_evidence_map')

inputs=[ROOT/'sources/FD7_CERTIFICATE_v0.7.0.json',source,ROOT/'analysis/verify_phase_python.py']+sorted(Path(__file__).parent.glob('*'))
manifest=dict(status='EXACT_QUANTITIES_CHECKED_BEFORE_RENDERING',biological_data=False,figures=5,graph_nodes=len(g['nodes']),graph_edges=len(g['edges']),
    numerical_plotting_only='Figure 4 samples an explicitly labelled analytical dimensionless function; no biological rate is assigned.',
    inputs={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs if p.is_file()},
    outputs={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for folder in [OUT,GOUT] for p in sorted(folder.rglob('*')) if p.is_file() and p.name!='FIGURE_PROVENANCE.json'},
    versions={'python':sys.version,'matplotlib':matplotlib.__version__,'numpy':np.__version__})
(OUT/'FIGURE_PROVENANCE.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:manifest[k] for k in ['status','figures','graph_nodes','graph_edges']}))

"""Analytical thresholds and exact finite-law probabilities, no sampled data."""
from pathlib import Path
from fractions import Fraction as F
import csv,hashlib,json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'axes.edgecolor':'#263C68','xtick.color':'#263C68','ytick.color':'#263C68','grid.color':'#E1DDEF','axes.prop_cycle':matplotlib.cycler(color=['#356FA8','#7364B5','#B94C8C','#86A6D3'])})
R=Path(__file__).resolve().parents[1];OUT=R/'figures-v07';OUT.mkdir(exist_ok=True)
with (R/'results/STATISTICAL_CROSSINGS.csv').open() as f:rows=list(csv.DictReader(f))
assert len(rows)==64 and all(F(r['valid_e_process_first_cross_probability'])<=F(1,20) for r in rows)
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
fig,axes=plt.subplots(2,1,figsize=(7.4,6.5),layout='constrained')
grid=range(4,513);plot_rows=[]
for t,color in [(0,'#166a83'),(.1,'#B94C8C'),(.25,'#654b91')]:
    vals=[t+math.sqrt(2*math.log(40)/n) for n in grid]
    axes[0].plot(grid,vals,label=f'Bias tolerance {t:g}',color=color)
    axes[0].axhline(t,color=color,ls='--',lw=.8)
    plot_rows.extend((n,t,v) for n,v in zip(grid,vals))
axes[0].set_xscale('log');axes[0].set_xlabel('Qualified experimental blocks (fixed horizon)');axes[0].set_ylabel('Rejection threshold');axes[0].set_title('A  Sampling allowance and persistent bias',loc='left',weight='bold');axes[0].legend(frameon=False,fontsize=9)
n=[int(r['blocks']) for r in rows]
axes[1].plot(n,[float(F(r['valid_e_process_first_cross_probability'])) for r in rows],label='Bounded-block e-process',color='#166a83')
axes[1].plot(n,[float(F(r['uncorrected_repeated_exact_binomial_probability'])) for r in rows],label='Repeated fixed-sample exact tests',color='#B94C8C')
axes[1].axhline(.05,color='#5a6471',ls='--',label='Nominal error 0.05')
axes[1].set_xlabel('Maximum number of independent fair blocks');axes[1].set_ylabel('Probability of any rejection');axes[1].set_title('B  Exact first-crossing probabilities',loc='left',weight='bold');axes[1].legend(frameon=False,fontsize=9)
for suffix in ('pdf','svg','png'):fig.savefig(OUT/('FIG8_statistical_inference.'+suffix),dpi=180)
plt.close(fig)
with (OUT/'data/statistical_thresholds.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['blocks','dimensionless_bias_tolerance','analytical_threshold_float_for_rendering']);w.writerows(plot_rows)
manifest=json.loads((OUT/'FIGURE_PROVENANCE.json').read_text());manifest.update(figures=9,main_figures=6,supplementary_figures=3)
for p in [Path(__file__),R/'results/STATISTICAL_INFERENCE.json',R/'results/STATISTICAL_CROSSINGS.csv']:manifest['inputs'][p.relative_to(R).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
for p in [*OUT.glob('FIG8_statistical_inference.*'),OUT/'data/statistical_thresholds.csv']:manifest['outputs'][p.relative_to(R).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(OUT/'FIGURE_PROVENANCE.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')

"""Analytical finite-reporter memory and endpoint accessibility; no biological fit."""
from pathlib import Path
import csv,hashlib,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'axes.edgecolor':'#263C68','xtick.color':'#263C68','ytick.color':'#263C68','grid.color':'#E1DDEF','axes.prop_cycle':matplotlib.cycler(color=['#356FA8','#7364B5','#B94C8C','#86A6D3'])})
from matplotlib.patches import FancyBboxPatch
R=Path(__file__).resolve().parents[1];OUT=R/'figures-v07'
audit=json.loads((R/'results/FINITE_REPORTER.json').read_text());assert audit['status']=='PASS_EXACT_FINITE_REPORTER'
theta=np.geomspace(.001,10,301)
fig,(ax,bx)=plt.subplots(2,1,figsize=(7.5,6.3),gridspec_kw={'height_ratios':[1.2,1]},layout='constrained')
rows=[]
for k,color in [(0,'#226eae'),(1,'#7364B5'),(3,'#B94C8C')]:
    values=np.exp(-k*theta)*(-np.expm1(-theta))/theta
    ax.plot(theta,values,color=color,label=f'{k} discarded periods')
    rows.extend(zip(theta,np.full_like(theta,k),values))
ax.axhline(0,color='#263C68',ls='--',label='After exact endpoint correction')
ax.set_xscale('log');ax.set_xlabel(r'$\theta=\delta T$ (dimensionless)');ax.set_ylabel('Mean contribution / initial error')
ax.set_title('A  Scalar reporter: one measured period',loc='left',weight='bold');ax.legend(fontsize=8)
bx.set_xlim(0,1);bx.set_ylim(0,1);bx.axis('off');bx.set_title('B  Maturation: both endpoint increments enter',loc='left',weight='bold')
for x,label,color in [(.04,'Synthesis\ninput','#eff3f6'),(.37,'Immature\nreporter i','#B94C8C'),(.70,'Mature\nfluorescence m','#EAE4F5')]:
    bx.add_patch(FancyBboxPatch((x,.53),.24,.25,boxstyle='round,pad=.015',facecolor=color,edgecolor='#526477'))
    bx.text(x+.12,.655,label,ha='center',va='center',fontsize=10)
for x in [.29,.62]:bx.annotate('',xy=(x+.065,.655),xytext=(x,.655),arrowprops={'arrowstyle':'->','color':'#226eae'})
bx.text(.5,.30,r'$Y^{\rm corr}=\overline{m}+(\Delta i+\Delta m)/(\delta H)$',ha='center',fontsize=14)
bx.text(.5,.10,'No immature-state degradation: a = maturation rate.\nMature fluorescence alone omits the immature endpoint term.',ha='center',fontsize=9)
for ext in ['pdf','svg','png']:fig.savefig(OUT/('FIG6_finite_reporter.'+ext),bbox_inches='tight',dpi=400)
plt.close(fig)
with (OUT/'data/reporter_memory.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['dimensionless_decay_period','discarded_periods','mean_initial_error_contribution']);w.writerows(rows)
manifest=json.loads((OUT/'FIGURE_PROVENANCE.json').read_text());manifest.update(figures=7,main_figures=4,supplementary_figures=3)
manifest['numerical_plotting_only']='Figures S3 and 4 sample labelled dimensionless analytical functions; no biological rates or observations are assigned.'
for p in [Path(__file__),R/'results/FINITE_REPORTER.json']:
    manifest['inputs'][p.relative_to(R).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
for p in [*OUT.glob('FIG6_finite_reporter.*'),OUT/'data/reporter_memory.csv']:
    manifest['outputs'][p.relative_to(R).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(OUT/'FIGURE_PROVENANCE.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS: finite reporter analytical figure and exact-audit linkage')

"""Supplementary coefficient arrays, rendered directly from exact certificates."""
from pathlib import Path
import hashlib,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'axes.edgecolor':'#263C68','xtick.color':'#263C68','ytick.color':'#263C68','grid.color':'#E1DDEF','axes.prop_cycle':matplotlib.cycler(color=['#356FA8','#7364B5','#B94C8C','#86A6D3'])})
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'figures-v07'
source=ROOT/'results/MARKOV_BOUNDARY.json';data=json.loads(source.read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'svg.fonttype':'none','pdf.fonttype':42})
fig,axes=plt.subplots(2,2,figsize=(7.2,6.4),layout='constrained',sharex=True,sharey=True)
for row,z in enumerate([0,1]):
    terms=data['two_state_polynomial_identities'][z]['coefficients'];assert sum(x[3] for x in terms)==288
    for col,s in enumerate([0,1]):
        a=np.zeros((13,13),dtype=int)
        for source_bit,n0,n1,c in terms:
            if source_bit==s:a[n1,n0]=c
        ax=axes[row,col];im=ax.imshow(a,origin='lower',cmap='Blues',vmin=0,vmax=12,interpolation='nearest')
        ax.set_title(f'Current symbol {z}, source symbol {s}');ax.set_xticks([0,3,6,9,12]);ax.set_yticks([0,3,6,9,12]);ax.set_xlabel('Exponent of b₀');ax.set_ylabel('Exponent of b₁')
fig.colorbar(im,ax=axes.ravel().tolist(),shrink=.8,label='Exact integer coefficient')
for ext in ['pdf','svg','png']:fig.savefig(OUT/('FIGS3_coefficients.'+ext),dpi=400,bbox_inches='tight')
plt.close(fig)
manifest=json.loads((OUT/'FIGURE_PROVENANCE.json').read_text());manifest.update(figures=6,main_figures=3,supplementary_figures=3)
for p in [Path(__file__),ROOT/'supplement-v07/data/Data_S1_polynomial_coefficients.csv']:
    manifest['inputs'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
for p in OUT.glob('FIGS3_coefficients.*'):manifest['outputs'][p.relative_to(ROOT).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(OUT/'FIGURE_PROVENANCE.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS: supplementary coefficient arrays, 332 exact nonzero terms')

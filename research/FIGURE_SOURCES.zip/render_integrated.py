from pathlib import Path
import sys
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
import numpy as np
R=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/content/e12/paper');O=R/'figures-integrated';O.mkdir(exist_ok=True)
blue='#356FA8';indigo='#48458F';pink='#B94C8C';pale='#EDF0FA';ink='#263C68';gray='#E0E4EF'
plt.rcParams.update({'font.family':'DejaVu Sans','text.color':ink,'axes.labelcolor':ink,'xtick.color':ink,'ytick.color':ink,'axes.edgecolor':ink,'font.size':10,'savefig.facecolor':'white'})
def box(ax,xy,w,h,text,color=blue,size=10):
 ax.add_patch(FancyBboxPatch(xy,w,h,boxstyle='round,pad=0.014,rounding_size=0.015',facecolor=pale,edgecolor=color,lw=1.5));ax.text(xy[0]+w/2,xy[1]+h/2,text,ha='center',va='center',fontsize=size,color=ink)
def arrow(ax,a,b,color=indigo,style='-'):
 ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=11,color=color,lw=1.3,linestyle=style))
for lang in ['ES','EN']:
 es=lang=='ES';fig=plt.figure(figsize=(11,6.5));ax=fig.add_axes([.04,.13,.44,.74]);ax.axis('off');ax.set_xlim(0,1);ax.set_ylim(-.04,1)
 ax.set_title('A  Marco referencial y relaciones' if es else 'A  Referential frame and relations',loc='left',fontweight='bold',fontsize=12,pad=20)
 box(ax,(.2,.78),.6,.13,'Adquisición / eventos' if es else 'Acquisition / events')
 box(ax,(.02,.5),.42,.14,'Reloj / segmento' if es else 'Clock / segment');box(ax,(.56,.5),.42,.14,'Fase / señal' if es else 'Phase / signal')
 arrow(ax,(.42,.78),(.23,.65));arrow(ax,(.58,.78),(.77,.65))
 box(ax,(.16,.23),.68,.14,'Intersección con identidad y soporte' if es else 'Intersection with identity and support',pink,9)
 arrow(ax,(.23,.5),(.39,.38));arrow(ax,(.77,.5),(.61,.38))
 box(ax,(.08,.01),.32,.1,'Predictor A');box(ax,(.6,.01),.32,.1,'Predictor B')
 arrow(ax,(.39,.06),(.6,.06),pink,'--');arrow(ax,(.4,.23),(.24,.12));arrow(ax,(.6,.23),(.76,.12))
 ax.text(.5,.16,'Contraste pareado' if es else 'Paired contrast',ha='center',fontsize=9,color=pink)
 ay=fig.add_axes([.66,.23,.3,.58]);lab=['Contexto\n84','Fase × señal\n756','Segmento\n252','Intersección\n2268'] if es else ['Context\n84','Phase × signal\n756','Segment\n252','Intersection\n2268'];y=np.arange(4)
 ay.barh(y-.17,[0,64,0,266],height=.3,color=indigo,label='Fija' if es else 'Fixed');ay.barh(y+.17,[0,6,1,81],height=.3,color=pink,label='Actualizada' if es else 'Updated')
 for yy,v in zip(y-.17,[0,64,0,266]):ay.text(v+4,yy,str(v),va='center',fontsize=10)
 for yy,v in zip(y+.17,[0,6,1,81]):ay.text(v+4,yy,str(v),va='center',fontsize=10)
 ay.set_yticks(y,lab);ay.invert_yaxis();ay.set_xlim(0,310);ay.spines[['right','top']].set_visible(False);ay.set_xlabel('Nodos con deterioro q95 >1%' if es else 'Nodes with q95 deterioration >1%');ay.legend(frameon=False,loc='lower right');ay.set_title('B  E11: daños locales' if es else 'B  E11: local harms',loc='left',fontweight='bold',fontsize=12,pad=22)
 fig.text(.04,.035,'Los niveles comparten eventos. Las flechas expresan relaciones del análisis, no mecanismos celulares.' if es else 'Levels share events. Arrows express analytical relations, not cellular mechanisms.',fontsize=10,color=ink)
 for ext in ['pdf','svg','png']:fig.savefig(O/f'LOCAL_EVIDENCE_{lang}.{ext}',dpi=160)
 plt.close(fig)
 fig,ax=plt.subplots(figsize=(11,6.8));ax.axis('off');ax.set_xlim(0,1);ax.set_ylim(0,1)
 ax.text(.02,.96,'Identidades temporales, observación y jurisdicciones' if es else 'Temporal identities, observation and jurisdictions',fontsize=18,fontweight='bold',va='top')
 boxes=[(.02,.64,.43,.2,'DISEÑO EXACTO\nFD7: nulo uniforme de dos estados\nFD8-32: extensión certificada' if es else 'EXACT DESIGN\nFD7: uniform two-state null\nFD8-32: certified extension',blue),(.55,.64,.43,.2,'CADENA DE OBSERVACIÓN\nReportero → ventana → entrega\nSaturación → inferencia secuencial' if es else 'OBSERVATION CHAIN\nReporter → window → delivery\nSaturation → sequential inference',indigo),(.02,.29,.43,.22,'DATOS CELULARES PUBLICADOS\nTransporte entre adquisiciones\nE11: 80/84 mejoras de RMSE\n81 excepciones finas de cola' if es else 'PUBLISHED CELLULAR RECORDINGS\nTransport across acquisitions\nE11: 80/84 RMSE improvements\n81 fine tail exceptions',pink),(.55,.29,.43,.22,'CARTOGRAFÍA REFERENCIAL\nAristas · intersecciones · escalas\nE12: operadores y aprendizaje futuro\nAbstenciones y daños conservados' if es else 'REFERENTIAL CARTOGRAPHY\nEdges · intersections · scales\nE12: operators and future learning\nAbstentions and harms retained',blue)]
 for x,y,w,h,tx,c in boxes:box(ax,(x,y),w,h,tx,c,11)
 arrow(ax,(.46,.74),(.54,.74));arrow(ax,(.76,.63),(.76,.52));arrow(ax,(.46,.4),(.54,.4));arrow(ax,(.23,.63),(.23,.52),style='--')
 ax.text(.5,.16,'La evidencia se integra conservando la jurisdicción de cada resultado.' if es else 'Evidence is integrated while preserving each result\'s jurisdiction.',ha='center',fontsize=12,fontweight='bold')
 ax.text(.5,.08,'La intervención celular directa FD7/FD8 permanece sin evaluar en estos registros.' if es else 'Direct cellular FD7/FD8 intervention remains untested in these records.',ha='center',fontsize=10)
 for ext in ['pdf','svg','png']:fig.savefig(O/f'VISUAL_ABSTRACT_{lang}.{ext}',dpi=160,bbox_inches='tight')
 plt.close(fig)
print('FIGURES_COMPLETE')

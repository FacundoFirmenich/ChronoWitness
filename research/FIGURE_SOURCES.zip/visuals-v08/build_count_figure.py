"""Render certified mathematical bounds; floating point only for plotting."""
from pathlib import Path
from fractions import Fraction as F
import csv,hashlib,json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'axes.edgecolor':'#263C68','xtick.color':'#263C68','ytick.color':'#263C68','grid.color':'#E1DDEF','axes.prop_cycle':matplotlib.cycler(color=['#356FA8','#7364B5','#B94C8C','#86A6D3'])})
R=Path(__file__).resolve().parents[1];OUT=R/'figures-v08'
with (R/'results/COUNT_TAIL_CURVES.csv').open() as f:rows=list(csv.DictReader(f))
with (R/'results/SATURATION_CROSSINGS.csv').open() as f:cross=list(csv.DictReader(f))
assert len(rows)==120 and len(cross)==24
assert all(F(r['stoploss_upper'])<=F(r['certified_bound']) for r in rows)
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
fig,axes=plt.subplots(3,1,figsize=(7.4,8.3),layout='constrained')
colors=['#166a83','#B94C8C','#654b91']
for p,color in zip(['0','1/4','1/2'],colors):
    rr=[r for r in rows if r['geometric_p']==p]
    axes[0].semilogy([int(r['cap']) for r in rr],[float(F(r['certified_bound'])) for r in rr],color=color,label=f'Batch p = {p}')
    oracle=[r for r in rr if F(r['stoploss_upper'])>F(1,10**23)]
    axes[0].semilogy([int(r['cap']) for r in oracle],[float((F(r['stoploss_lower'])+F(r['stoploss_upper']))/2) for r in oracle],color=color,ls='--',lw=1)
axes[0].set_ylim(1e-12,10);axes[0].set_xlabel('Count cap m');axes[0].set_ylabel('Expected excess / bound');axes[0].set_title('A  Certified saturation-loss bounds',loc='left',weight='bold')
axes[0].legend(frameon=False,fontsize=8,ncol=3);axes[0].text(.98,.06,'Solid: certified bound\nDashed: enclosed expectation',ha='right',transform=axes[0].transAxes,fontsize=8)
rr=[r for r in rows if r['geometric_p']=='0'];plot=[]
for n,color in zip([64,256,1024],colors):
    vals=[2*float(F(r['certified_bound']))+int(r['cap'])*math.sqrt(2*math.log(40)/n) for r in rr]
    axes[1].plot([int(r['cap']) for r in rr],vals,color=color,label=f'n = {n}')
    plot.extend((n,r['cap'],r['certified_bound'],v) for r,v in zip(rr,vals))
axes[1].set_xlabel('Count cap m');axes[1].set_ylabel('Fixed-sample allowance');axes[1].set_title('B  Bias–range tradeoff under declared envelopes',loc='left',weight='bold');axes[1].legend(frameon=False,fontsize=8,ncol=3)
xx=[int(r['blocks']) for r in cross]
axes[2].plot(xx,[float(F(r['naive_first_cross_probability'])) for r in cross],color='#B94C8C',label='Saturation bias omitted')
axes[2].plot(xx,[float(F(r['bias_qualified_first_cross_probability'])) for r in cross],color='#166a83',label='Bias tolerance 1/2 included')
axes[2].axhline(.05,color='#5a6471',ls='--',lw=.8,label='Nominal error 0.05')
axes[2].set_xlabel('Maximum number of independent blocks');axes[2].set_ylabel('Probability of any rejection');axes[2].set_ylim(-.025,1.025);axes[2].set_title('C  Equal latent means under detector saturation',loc='left',weight='bold');axes[2].legend(frameon=False,fontsize=8,loc='upper left')
for ext in ('pdf','svg','png'):fig.savefig(OUT/('FIG9_count_tails.'+ext),dpi=180)
plt.close(fig)
with (OUT/'data/count_tail_tradeoff.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['fixed_blocks','cap','per_arm_bias_bound','allowance_float_for_rendering']);w.writerows(plot)
manifest=json.loads((OUT/'FIGURE_PROVENANCE.json').read_text());manifest.update(figures=10,main_figures=7,supplementary_figures=3)
for p in [Path(__file__),R/'results/COUNT_TAILS.json',R/'results/COUNT_TAIL_CURVES.csv',R/'results/SATURATION_CROSSINGS.csv']:manifest['inputs'][p.relative_to(R).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
for p in [*OUT.glob('FIG9_count_tails.*'),OUT/'data/count_tail_tradeoff.csv']:manifest['outputs'][p.relative_to(R).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(OUT/'FIGURE_PROVENANCE.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')

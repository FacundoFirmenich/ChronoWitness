"""Curated logical/evidential graph. Edges are assertions, never measured biology."""
import json
from pathlib import Path

LAYERS=['Design','Contracts','Results','Evidence','Boundaries','Next decisions']
N=[]; E=[]
def node(id,label,layer,status,detail,source):
    N.append(dict(id=id,label=label,layer=layer,status=status,detail=detail,source=source))
def edge(a,b,kind): E.append(dict(source=a,target=b,kind=kind))

node('fd7','FD7 schedules',0,'exact','Two cyclic binary words of length 24, each with twelve 0s and twelve 1s. Design inputs, not cell measurements.','MANUSCRIPT_EN.md §3.1; sources/FD7_CERTIFICATE_v0.7.0.json')
node('words','Orders 1–7 matched',0,'exact','Cyclic word-count vectors coincide through order seven; their L1 difference first becomes 8 at order eight.','§4.1; analysis/audit_design_structure.py')
node('runs','Runs and autocorrelation',0,'exact','The symbol-labelled run multisets and cyclic autocorrelations coincide. These summaries alone do not prove reader equivalence.','§4.1; analysis/audit_design_structure.py')
node('symmetry','No trivial symmetry',0,'exact','The schedules are not related by rotation, reversal, complementation or their combinations.','§4.1; analysis/audit_design_structure.py')
node('delivery','Qualified delivered input',0,'conditional','The kinetic interpretation requires actual delivered symbols, equal interval duration and no undeclared feedback. A commanded schedule alone is insufficient.','§5–6')
node('exposure','ExposureBounds 4.16',0,'separate','The exposure program has its own acquisitions, assumptions and certificates. It has not been composed into an FD7 biological guarantee.','https://github.com/FacundoFirmenich/ExposureBounds')
node('phase','Uniform phase contract',1,'conditional','Phase is uniformly represented, independent of initial state and omitted from the reported deterministic profile. Common initial mixtures are allowed.','§3.1; §4.2')
node('occupation','Occupation readout',1,'conditional','State–symbol proportions before symbol processing. Neither the full path nor a finite-word endpoint probability is the reported functional.','§3.1')
node('detclass','Deterministic readers',1,'conditional','Time-homogeneous binary transition tables on labelled finite states. The count is not a prevalence in biology.','§3.1–3.2')
node('markovclass','Positive Markov readers',1,'conditional','Strictly positive input-conditioned discrete-time row-stochastic matrices in the periodic invariant regime.','§3.1; §4.4')
node('kineticclass','Two-state promoter',1,'conditional','Positive symbol-conditioned switching rates, equal symbol duration, common parameters and periodic equilibration. Promoter state count is not whole-cell state count.','§4.7; Theorem 2')
node('linear','Linear observation cascade',1,'conditional','Constant common degradation, or a common stable time-independent linear cascade, with complete-period means.','§4.7; Theorem 2')
node('mixture','Common parameter mixture',1,'conditional','A fixed shared distribution of kinetic parameters with finite required expectations. History-dependent weighting is excluded.','§4.7; reference 33')
node('instrument','Reader–instrument contract',1,'conditional','One-way reader and instrument each have two internal states. Instrument state is part of the measurement dynamics.','§4.5')
node('det4','Deterministic minimum: 4',2,'exact','No reader with at most three states separates phase-balanced stationary-profile laws. A synchronizing four-state reader separates by 1/24 in state 3.','§4.2')
node('criterion','Polynomial iff criterion',2,'exact','For equal-length matched-count words, equality of both conditional occupation polynomials is necessary and sufficient for equality for all positive two-state readers.','§4.3; Proposition 1')
node('markov3','Positive Markov minimum: 3',2,'exact','The two-state coefficient identity supplies the lower bound. A positive three-state witness supplies the upper bound for this occupation functional.','§4.3–4.4')
node('margin','Witness margin: 5/131072',2,'exact','State-0 occupation difference for the displayed three-state matrices only. It is neither an optimized margin nor a biological observation.','§4.4; results/MARKOV_BOUNDARY.json')
node('cascade','Instrument can separate',2,'exact','A 2×2 cascade separates with runwise absolute deviation 1/6 versus 0. Pooling signed phase means before the nonlinearity changes the statistic.','§4.5')
node('kineticnull','Promoter-integral equality',2,'exact','Under the kinetic contract, integrated active-state occupancy over each symbol class is equal for the two schedules for every positive rate pair.','§4.7; Theorem 2')
node('reporternull','Expression-mean equality',2,'exact','Integrated linear moment equations transport the activity equality to a common stable linear readout mean in the periodic regime.','§4.7; Theorem 2')
node('contraction','Exact kinetic contraction',2,'exact','Initial promoter differences contract per period by exp[-12 Delta (kappa_0+kappa_1)]. This factor can approach one.','§4.7')
node('enum','Exhaustive deterministic audit',3,'evidence','1, 16, 729 and 65536 labelled tables for 1–4 states; all initial states and 24 phases. Independent Python verification exhausts the lower classes.','analysis/audit_phase_ensemble.cpp; analysis/verify_phase_python.py')
node('poly','Independent coefficient builders',3,'evidence','Backward cyclic coefficients and forward symbolic recurrence agree exactly; FD7 has 153 and 179 monomials for current symbols 0 and 1.','analysis/audit_markov_boundary.py; analysis/verify_markov_boundary.py')
node('propagate','Exact rational propagation',3,'evidence','The three-state witness is independently propagated from all basis initial distributions and rotations: 144 word–phase–initial cases.','analysis/verify_markov_boundary.py')
node('negative','General-criterion audit',3,'evidence','All 510 binary words of lengths 1–8 and their rotations are checked. Matched-count 0011 versus 0101 supplies a separating negative control.','analysis/audit_general_criterion.py')
node('instrumentaudit','4096 cascade tables',3,'evidence','All 4096 one-way 2×2 tables and 16384 table–initial-state cases are audited. 44 table–initial-state pairs separate instrument means; 52 separate instrument profile laws.','analysis/audit_reader_instrument.cpp; analysis/verify_reader_instrument.py')
node('integration','Analytical interval integration',3,'evidence','Exact integration of the two-state exponential response and a full-period linear balance establish the conditional kinetic and reporter equalities.','§4.7; Theorem 2')
node('literature','Related literature',3,'context','Mechanistic memory, dynamic inputs, stochastic transcription, observation, model discrimination and embedding. Related work supplies context, not experimental validation of FD7.','Main article references; Supplementary Information references')
node('phaseadverse','Phase-labelled separation',4,'adverse','A two-state reader separates at selected phases, while the historical absorbing four-state witness fails the phase-balanced law test. These earlier boundaries remain explicit.','§4.2; Figure S1')
node('nonembed','Witness is not CTMC-embeddable',4,'adverse','Displayed determinants are -1/4 and 0. A finite homogeneous continuous-time propagator has strictly positive determinant. This blocks transporting the three-state upper bound.','§4.7; reference 34')
node('noctmc','No continuous-time upper bound',4,'open','The discrete positive three-state witness does not establish a three-state kinetic separator. Existence and useful margin remain separate questions.','§4.5–4.6')
node('noagency','No agency or cellular state count',4,'boundary','Excluding a finite comparator under a qualified readout does not establish agency, cognition, a unique mechanism or the number of states in a cell.','Abstract; §7')
node('notpath','Means are not path laws',4,'boundary','Equal occupations or expression means do not imply equal burst distributions, correlation functions, finite random measurements or full trajectories.','§3–4; references 19–24, 32')
node('nowashin','No uniform finite wash-in',4,'adverse','Across all positive rates without a lower bound, the contraction can approach one. No common finite equilibration time follows.','§4.7')
node('nonlinear','Excluded observation changes',4,'boundary','Nonlinear or time-dependent readouts, symbol-dependent degradation, feedback, transients and history-dependent mixture weights are not covered by the mean null.','§4.7; §6')
node('nobiology','No new biological observations',4,'boundary','All numerical certificates concern mathematical designs and models. No FD7 cell experiment, calibrated delivery or causal localization has been performed.','Abstract; §6–7')
node('qualify','Qualify delivery and timing',5,'open','Measure or justify the delivered input, interval duration, wash-in and observation window before interpreting a biological contrast.','§5–6')
node('localize','Audit the observation process',5,'open','Separate upstream memory from instrument and reporter dynamics; retain the actual experimental unit and sampling design.','§6; references 28, 31')
node('ctmcresearch','Search within kinetic models',5,'open','A continuous-time separator must be established within its own generator class and readout; current non-embedding evidence cannot be bypassed.','§7')
node('qualifiedrejection','Interpret a qualified violation',5,'conditional','A reproducible violation rejects the conjunction of comparator and delivery/measurement assumptions. It does not uniquely identify which assumption failed.','§5–7')
node('review','External scientific review',5,'open','Priority, proof interpretation and biological scope still require independent scrutiny. Repository CI is not peer review.','README.md; §7')
node('experiment','Prospective biological assay',5,'open','No observed FD7 biological outcome exists in this package. Any future assay requires a defined estimand, independent units and error analysis.','§6')

for target in ['words','runs','symmetry']: edge('fd7',target,'verified_as')
for source in ['fd7','phase','occupation','detclass']:edge(source,'det4','requires' if source!='fd7' else 'instantiates')
for a,b in [('enum','det4'),('poly','criterion'),('poly','markov3'),('propagate','margin'),('negative','criterion'),('instrumentaudit','cascade'),('integration','kineticnull'),('integration','reporternull')]:edge(a,b,'supports')
for a,b in [('markovclass','markov3'),('occupation','markov3'),('instrument','cascade'),('delivery','kineticnull'),('kineticclass','kineticnull'),('linear','reporternull'),('mixture','reporternull')]:edge(a,b,'requires')
for a,b in [('criterion','markov3'),('margin','markov3'),('kineticnull','reporternull')]:edge(a,b,'supports')
for a,b in [('phaseadverse','det4'),('nonembed','noctmc'),('contraction','nowashin'),('cascade','localize')]:edge(a,b,'constrains')
for a,b in [('markov3','noctmc'),('det4','noagency'),('markov3','noagency'),('reporternull','notpath'),('exposure','kineticnull')]:edge(a,b,'does_not_imply')
for a,b in [('nowashin','qualify'),('nonlinear','localize'),('noctmc','ctmcresearch'),('nobiology','experiment'),('literature','review'),('delivery','qualify')]:edge(a,b,'motivates')
for a in ['kineticnull','reporternull']:edge(a,'qualifiedrejection','supports')
for a in ['qualify','localize','experiment']:edge(a,'qualifiedrejection','requires')
for a in ['det4','markov3','kineticnull','reporternull']:edge(a,'review','requires_review')
edge('reporternull','nonlinear','bounded_by');edge('kineticclass','contraction','implies')
edge('fd7','poly','input_to');edge('fd7','enum','input_to');edge('occupation','notpath','bounded_by')
edge('literature','kineticclass','contextualizes');edge('literature','localize','contextualizes')
edge('runs','det4','does_not_prove');edge('words','markov3','does_not_prove')

node('finitebias','Finite promoter-window bias',2,'exact','The exact transient bias after k discarded and r measured periods is e(0) J rho^k (1-rho^r)/(r T (1-rho)). The contrast bound is conditional on rates and initial errors; it does not bound reporter or sampling noise.','Supplementary Information §S6.3')
node('transientcheck','Rational transient coefficient audit',3,'evidence','Direct affine propagation and the closed geometric formula agree coefficientwise for h0 and h1 over the declared rational parameter and window grid.','supplement-v08/data/Data_S5_supplement_checks.json')
for a,b,kind in [('kineticclass','finitebias','requires'),('contraction','finitebias','supports'),('transientcheck','finitebias','supports'),('finitebias','qualify','supports'),('finitebias','localize','does_not_imply'),('finitebias','nowashin','bounded_by')]:edge(a,b,kind)
N[:]=[n for n in N if n['id'] not in {'exposure','review'}]
E[:]=[e for e in E if e['source'] not in {'exposure','review'} and e['target'] not in {'exposure','review'}]


node('reporterfinite','Finite reporter balance',2,'exact','An endpoint-corrected mean removes the contribution of reporter initial states; the remaining promoter bias has a closed geometric expression.','Supplementary Information S10.1; Theorem 3')
node('endpointaccess','Accessible endpoint correction',1,'conditional','C A^-1 must belong to the row span of endpoint measurement R to obtain the correction from R times the state increment alone.','Supplementary Information S10.2')
node('hiddenendpoint','Hidden maturation contribution',4,'adverse','Mature fluorescence increments alone generally omit an immature-state term required by the correction. Additional trajectory-based state reconstruction is a separate question.','Supplementary Information S10.2')
node('reporterbound','Certified raw-window bound',2,'exact','A verified positive weighted contraction certificate bounds initial reporter and promoter transients, including coincident contraction rates.','Supplementary Information S10.3')
node('reportercheck','Independent exact reporter audit',3,'evidence','Spectral projectors and componentwise ODE solutions verify 6912 finite windows with rational arithmetic and rigorous log(2) bounds.','finite_reporter/verify.py; Supplementary Data S6')
for a,b,kind in [('linear','reporterfinite','requires'),('finitebias','reporterfinite','supports'),('endpointaccess','reporterfinite','requires'),('hiddenendpoint','endpointaccess','bounded_by'),('reportercheck','reporterfinite','supports'),('reportercheck','reporterbound','supports'),('linear','reporterbound','requires'),('reporterbound','qualify','supports'),('reporterfinite','qualify','supports')]:edge(a,b,kind)


node('deliverybound','Delivered-input contrast bound',2,'exact','Weighted coefficient errors and initial-state bounds control the corrected FD7 contrast; positive cascades also admit a raw-window bound.','Supplementary Information S11.1-S11.3; Theorem 4')
node('gaincontract','Calibrated per-arm delivery',1,'conditional','Input-to-rate and synthesis gains, rate lower bounds and per-arm envelopes must apply on the declared amplitude range and common time axis.','Supplementary Information S11.4')
node('timingbudget','Weighted transition-displacement budget',2,'exact','A shifted transition contributes over its swept interval, using the acquisition kernel rather than only an unweighted duration.','Supplementary Information S11.4')
node('commonmode','Differential exposure misses common mode',4,'adverse','An unchanged pointwise input difference can coexist with corrected reporter contrast 1/(4 delta) under quadratic synthesis.','Supplementary Information S11.5')
node('historyerror','Pre-window delivery memory',4,'adverse','Errors before acquisition can survive into the output even when delivered input is exact throughout the measured window.','Supplementary Information S11.2-S11.3')
node('inputcheck','Exact input and kernel audit',3,'evidence','1728 windows; independent flow constructions and kernel-versus-ODE recurrence checks, including coincident contraction rates.','input_robustness/verify.py; Supplementary Data S7')
for a,b,kind in [('reporterfinite','deliverybound','supports'),('reporterbound','deliverybound','supports'),('gaincontract','deliverybound','requires'),('timingbudget','deliverybound','supports'),('inputcheck','deliverybound','supports'),('inputcheck','timingbudget','supports'),('commonmode','gaincontract','motivates'),('historyerror','deliverybound','constrains'),('deliverybound','qualify','supports'),('deliverybound','qualifiedrejection','supports'),('gaincontract','timingbudget','requires')]:edge(a,b,kind)

node('statcontract','Qualified block and score range',1,'conditional','A predictable conditional mean tolerance and a valid range of the complete observed block score are separate requirements.','Supplementary Information S12.1')
node('randomizedpair','Randomized pair cancels baselines',2,'exact','Fair paired assignment cancels unequal unit reference means in expectation, under all four potential-mean bounds and no interference.','Supplementary Information S12.2')
node('endpointnoise','Endpoint uncertainty propagation',2,'exact','The corrected observable transports joint endpoint and average errors through one linear functional; covariance terms cannot be silently dropped.','Supplementary Information S12.3')
node('anytime','Rejection under optional stopping',2,'exact','A nonnegative mixture supermartingale controls any-time false rejection under the conditional bounded-block null.','Theorem 5; Supplementary Information S12.5')
node('statcheck','Exact statistical-law audit',3,'evidence','8194 positive-probability paths, 65632 local component inequalities, independent integer first-crossing counts and adverse controls.','statistical_inference/verify.py; Supplementary Data S8')
node('pseudorep','Duplicated blocks invalidate sampling',4,'adverse','Six copies of a single fair outcome can force false rejection if mistakenly counted as new blocks.','Supplementary Information S12.7')
node('rangeboundary','Unqualified range or clipping',4,'adverse','The model mean bound is not a score range. Clipping can shift a zero mean and requires its own bias bound.','Supplementary Information S12.5')
for a,b,kind in [('deliverybound','statcontract','supports'),('endpointnoise','statcontract','supports'),('randomizedpair','statcontract','supports'),('statcontract','anytime','requires'),('statcheck','anytime','supports'),('statcheck','randomizedpair','supports'),('statcheck','endpointnoise','supports'),('pseudorep','statcontract','constrains'),('rangeboundary','statcontract','constrains'),('anytime','qualifiedrejection','supports'),('statcontract','experiment','requires'),('anytime','noagency','bounded_by'),('statcheck','pseudorep','supports')]:edge(a,b,kind)

node('countcontract','Qualified population and production',1,'conditional','Initial count moments or PGF and a dominating arrival/batch law must hold conditionally before the block.','Supplementary Information S13.3')
node('countenvelope','Count-tail and stop-loss bounds',2,'exact','Moment and PGF envelopes control expected excess above detector caps without bounding latent counts almost surely.','Supplementary Information S13.2-S13.3')
node('saturationtransport','Saturation-to-test transport',2,'exact','Transport the expected distortion through the readout and endpoints, then add it to the conditional mean tolerance of Theorem 5.','Theorem 6; Supplementary Information S13.1-S13.4')
node('countaudit','Certified count and detector audit',3,'evidence','360 stop-loss cases, 1560 PGF inequalities, independent compound-Poisson coefficients, reaction invariants and exact first-crossing counts.','count_tails/verify.py; Supplementary Data S9')
node('countbranching','Branching needs a production envelope',4,'boundary','Nonbranching maturation and degradation do not create molecules. Explicit translation needs additional domination or a justified burst model.','Supplementary Information S13.3')
node('satadverse','Saturation can break an equal-mean null',4,'adverse','Equal unsaturated means can become different capped means. A zero-bias test can then reject with probability far above its nominal level.','Supplementary Information S13.5')
node('tailcalibration','Qualify count and detector contracts',5,'open','Initial population, production, burst law, caps, gains and experimental units remain external assay inputs.','Supplementary Information S13.7')
for a,b,kind in [('countcontract','countenvelope','requires'),('countenvelope','saturationtransport','supports'),('endpointnoise','saturationtransport','supports'),('saturationtransport','anytime','supports'),('statcontract','saturationtransport','requires'),('countaudit','countenvelope','supports'),('countaudit','saturationtransport','supports'),('countbranching','countenvelope','constrains'),('satadverse','saturationtransport','motivates'),('tailcalibration','countcontract','requires'),('rangeboundary','saturationtransport','motivates'),('reporterfinite','saturationtransport','supports'),('gaincontract','countcontract','requires'),('saturationtransport','qualifiedrejection','supports')]:edge(a,b,kind)

def graph():

    sources={'fd7': 'S1–S2', 'words': 'S2', 'runs': 'S2', 'symmetry': 'S2', 'delivery': 'S6, S8', 'phase': 'S1, S3', 'occupation': 'S1', 'detclass': 'S3', 'markovclass': 'S1, S4–S5', 'kineticclass': 'S6', 'linear': 'S6', 'mixture': 'S6', 'instrument': 'S7', 'det4': 'S3', 'criterion': 'S4', 'markov3': 'S4–S5', 'margin': 'S5', 'cascade': 'S7', 'kineticnull': 'S6', 'reporternull': 'S6', 'contraction': 'S6', 'phaseadverse': 'S3; Figure S1', 'nonembed': 'S5; reference S1', 'noctmc': 'S5–S6', 'noagency': 'S8', 'notpath': 'S1, S8', 'nowashin': 'S6', 'nonlinear': 'S6, S8', 'nobiology': 'S1, S9', 'qualify': 'S6, S8', 'localize': 'S7–S8', 'ctmcresearch': 'S5', 'qualifiedrejection': 'S8, S12', 'review': 'S9', 'experiment': 'S8'}
    for n in N:
        if n['id'] in sources:n['source']='Supplementary Information §'+sources[n['id']]
    ids={n['id'] for n in N};assert len(ids)==len(N)
    assert all(e['source'] in ids and e['target'] in ids for e in E)
    assert len({(e['source'],e['target'],e['kind']) for e in E})==len(E)
    return dict(title='ChronoWitness · claims, evidence and limits',version='0.8',
        scope='Logical/evidential graph; not a biological network or numerical confidence model.',
        layers=LAYERS,nodes=N,edges=E,biological_data=False,
        supplementary='supplement-v08/SUPPLEMENTARY_INFORMATION.md')

if __name__=='__main__':
    target=Path(__file__).resolve().parents[1]/'graph-v08';target.mkdir(exist_ok=True)
    (target/'epistemic_graph.json').write_text(json.dumps(graph(),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

from pathlib import Path
import subprocess,sys,json,shutil
R=Path(__file__).resolve().parent
for c in json.loads((R/'COMMANDS.json').read_text()):
 subprocess.run([sys.executable,str(R/c)]+([str(R)] if c=='render_integrated.py' else []),check=True,cwd=R)
for src,dst in [('e5-nested-20261111/figures','figures-e5'),('e8/figures-e8','figures-e8')]:shutil.copytree(R/src,R/dst,dirs_exist_ok=True)
print('All declared generators completed. PDF/SVG/PNG outputs retain versioned directories.')

from pathlib import Path
import os
os.environ['MPLBACKEND']='Agg'
import json,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'axes.edgecolor':'#263C68','xtick.color':'#263C68','ytick.color':'#263C68','grid.color':'#E1DDEF','axes.prop_cycle':matplotlib.cycler(color=['#356FA8','#7364B5','#B94C8C','#86A6D3'])})
from matplotlib.patches import FancyBboxPatch
P=Path(__file__).resolve().parents[1];out=P/'figures-v013';out.mkdir(exist_ok=True)
r=json.loads((P/'empirical-v013/E4/results/LOCAL_METRICS.json').read_text())
g=json.loads((P/'empirical-v013/E4/results/GLOBAL_CONTEXT.json').read_text())
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
fig,axs=plt.subplots(1,2,figsize=(10,4),gridspec_kw={'width_ratios':[1,1.2]},layout='constrained')
policies=['local_offset','local_affine','local_equalmix','local_gate'];names=['Local offset','Local affine','Fixed mixture','Local selection']
counts=np.array([[sum(x['label']==lab for x in r if x['policy']==p) for lab in ['LOCAL_OBSERVED_GAIN','PRACTICAL_TIE','LOCAL_OBSERVED_LOSS']] for p in policies])
left=np.zeros(4)
for j,(lab,color) in enumerate(zip(['MAE gain >1%','Practical tie','MAE loss >1%'],['#087f8c','#BDB0DA','#B94C8C'])):
    axs[0].barh(names,counts[:,j],left=left,label=lab,color=color)
    for i,n in enumerate(counts[:,j]):
        if n:axs[0].text(left[i]+n/2,i,str(n),ha='center',va='center',fontsize=8)
    left+=counts[:,j]
axs[0].set(xlabel='Jurisdictions on common support (n=270)',title='A  Local comparison');axs[0].legend(loc='lower center',bbox_to_anchor=(.5,-.38),fontsize=7,ncol=2,frameon=False)
dates=['2022-04-15','2022-04-21','2022-04-23'];x=np.arange(3)
for j,(field,label,color) in enumerate([('mae','MAE','#087f8c'),('rmse','RMSE','#3c5b8a'),('tail05_mean','Upper-tail mean','#B94C8C')]):
    vals=[]
    for d in dates:
        q={a['policy']:a for a in g if a['date']==d and a['offset']==1 and a['horizon']==12}
        vals.append(100*(1-q['local_gate'][field]/q['raw'][field]))
    axs[1].bar(x+(j-1)*.24,vals,width=.23,label=label,color=color)
axs[1].set(xticks=x,xticklabels=['15 Apr','21 Apr','23 Apr'],ylabel='Error reduction (%)',title='B  Primary-horizon aggregate context');axs[1].axhline(0,color='#555',lw=.8);axs[1].legend(loc='lower center',bbox_to_anchor=(.5,-.38),ncol=3,fontsize=7,frameon=False)
fig.savefig(out/'FIGURE_14.pdf');fig.savefig(out/'FIGURE_14.png',dpi=400);plt.close(fig)
fig,axs=plt.subplots(1,3,figsize=(10,7),layout='constrained')
for ax,d in zip(axs,dates):
    vals=np.full((12,3),np.nan);markers=[]
    for row in r:
        if row['date']!=d or row['offset']!=1 or row['horizon']!=12 or row['policy']!='local_gate':continue
        i=[132,156,180].index(row['segment_start'])*4+['00','01','10','11'].index(row['edge']);j=['low','middle','high'].index(row['band'])
        if row['status']=='SUPPORTED':vals[i,j]=100*row['relative_MAE_gain']
        else:markers.append((i,j,'x' if row['status']=='NOT_ESTIMABLE' else 'o'))
    im=ax.imshow(np.ma.masked_invalid(vals),vmin=0,vmax=70,cmap='BuPu',aspect='auto')
    for i,j,m in markers:ax.text(j,i,m,ha='center',va='center',color='#555')
    ax.set(xticks=range(3),xticklabels=['Low','Middle','High'],yticks=range(12),yticklabels=[f'{s} / {e}' for s in ['132–155','156–179','180+'] for e in ['00','01','10','11']],title=d)
    for y in [3.5,7.5]:ax.axhline(y,color='white',lw=2)
fig.colorbar(im,ax=axs,label='MAE reduction (%) on supported jurisdictions',shrink=.7)
fig.savefig(out/'FIGURE_S21.pdf');fig.savefig(out/'FIGURE_S21.png',dpi=400);plt.close(fig)
fig=plt.figure(figsize=(10,7));ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,10),ylim=(0,7));ax.axis('off')
ax.text(.5,6.55,'ChronoWitness',fontsize=24,weight='bold',color='#113b57');ax.text(.5,6.15,'Temporal identities · measured contrasts · local calibration',fontsize=12,color='#465b6c')
boxes=[(.5,3.8,'1  Design an exact contrast','Two periodic binary schedules, L=24\nMatched short words, runs and autocorrelation\nUniform two-state occupation null'),(5.2,3.8,'2  Certify model separation','Four deterministic states suffice\nThree kinetic states suffice\nCertified contrast >0.01007'),(.5,1.55,'3  Qualify the observation','Reporter and endpoint information\nDelivery, transient and saturation budgets\nBlock-level test with optional stopping'),(5.2,1.55,'4  Resolve empirical transport','Published cell measurements; E1–E4\n129 local MAE gains; 141 practical ties\n270 supported contexts; tail tradeoffs retained')]
for x,y,title,body in boxes:
    ax.add_patch(FancyBboxPatch((x,y),4.25,1.75,boxstyle='round,pad=.12',facecolor='#edf4f8',edgecolor='#8da8b8'))
    ax.text(x+.15,y+1.37,title,fontsize=12,weight='bold',color='#113b57');ax.text(x+.15,y+.99,body,fontsize=10,va='top',linespacing=1.7,color='#263C68')
ax.annotate('',xy=(5.03,4.65),xytext=(4.86,4.65),arrowprops={'arrowstyle':'->','lw':1.8,'color':'#087f8c'})
ax.text(.5,.75,'Exact identities and secondary cellular observations are distinct evidence layers.',fontsize=11,weight='bold',color='#113b57')
ax.text(.5,.35,'The published cellular input programs do not constitute a paired FD7 intervention.',fontsize=10,color='#465b6c')
fig.savefig(out/'VISUAL_ABSTRACT.pdf');fig.savefig(out/'VISUAL_ABSTRACT.png',dpi=400);plt.close(fig)
print('Three publication figures generated from E4 records.')

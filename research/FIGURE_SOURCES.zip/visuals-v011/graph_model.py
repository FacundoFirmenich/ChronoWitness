from pathlib import Path
import runpy,json
R=Path(__file__).resolve().parents[1]
def graph():
 g=json.loads(json.dumps(runpy.run_path(str(R/'visuals-v010/graph_model.py'))['graph']()))
 def node(id,label,layer,status,detail):g['nodes'].append(dict(id=id,label=label,layer=layer,status=status,detail=detail,source='Main 3.12–3.13; SI S16–S17; Data S12'))
 node('designsearch','Fixed-domain kinetic search',3,'evidence','Three seeds, fixed positive-rate box and normalized state-zero objective. Each search exhausted its generation budget; global optimality is not claimed.')
 node('designcert','Certified contrast above 0.01007',2,'exact','Rationalized positive generators have integrated contrast enclosed independently by uniformization and a tree formula. A rate neighborhood preserves half of the margin.')
 node('powerlaws','Declared block alternatives',1,'conditional','The exact power study uses iid two-point scores with specified probabilities, support and mean tolerance. The tutorial specifies a distinct ideal paired-state observation.')
 node('poweraudit','Exact first-crossing probabilities',3,'evidence','Integer prefix counting supplies 120 horizon entries; independent path enumeration checks capital and crossings. Additional small stakes need not improve finite-horizon power.')
 for a,b,k in [('ctmccontract','designcert','requires'),('designsearch','designcert','supports'),('ctmc3','designsearch','motivates'),('designcert','ctmcrobust','extends'),('powerlaws','poweraudit','requires'),('anytime','poweraudit','supports'),('saturationtransport','powerlaws','qualifies'),('designcert','powerlaws','motivates')]:g['edges'].append(dict(source=a,target=b,kind=k))
 g['version']='0.11';g['supplementary']='supplement-v011/SUPPLEMENTARY_INFORMATION.md'
 assert len(g['nodes'])==82 and len(g['edges'])==134
 return g

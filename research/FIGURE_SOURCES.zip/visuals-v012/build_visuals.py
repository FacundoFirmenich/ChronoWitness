"""Publication figures from recorded computations; no illustrative data curves."""
from pathlib import Path
from fractions import Fraction as F
import csv,hashlib,json,runpy,textwrap
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'axes.edgecolor':'#263C68','xtick.color':'#263C68','ytick.color':'#263C68','grid.color':'#E1DDEF','axes.prop_cycle':matplotlib.cycler(color=['#356FA8','#7364B5','#B94C8C','#86A6D3'])})
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch,Rectangle,Circle
import numpy as np
R=Path(__file__).resolve().parents[1];O=R/'figures-v012';G=R/'graph-v012';D=R/'supplement-v012/data'
O.mkdir(exist_ok=True);G.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42})
blue,red,teal,gray='#176580','#B94C8C','#7364B5','#53616d'
def save(fig,name):
 for ext in ['pdf','svg','png']:fig.savefig(O/(name+'.'+ext),dpi=190)
 plt.close(fig)
mom=json.loads((D/'Data_S13_assay_moments.json').read_text())['records']
power=json.loads((D/'Data_S13_assay_audit.json').read_text())['power']
def record(model,arm,periods):return next(r for r in mom if r['model']==model and r['arm']==arm and r['periods']==periods)
models=['two_state_null','certified_three_state'];labels=['Two-state null','Three-state reader']
fig,ax=plt.subplots(2,2,figsize=(8,7.1),layout='constrained')
for j,kind in enumerate(['raw','corrected']):
 vals=[]
 for model in models:
  a,b=record(model,0,1),record(model,1,1)
  vals.append(a['reporters'][0]['raw_mean']-b['reporters'][0]['raw_mean'] if kind=='raw' else a['mean']-b['mean'])
 ax[0,0].bar(np.arange(2)+(j-.5)*.32,vals,.30,label=['Raw reporter','Endpoint corrected'][j],color=[red,blue][j])
ax[0,0].axhline(0,color=gray,lw=.7);ax[0,0].set_xticks(range(2),labels,fontsize=8);ax[0,0].set_ylabel('Paired mean contrast');ax[0,0].legend(frameon=False,fontsize=8);ax[0,0].set_title('A  Observation can change the sign',loc='left',weight='bold',fontsize=10)
for j,p in enumerate([1,4]):
 vals=[record(m,0,p)['variance']+record(m,1,p)['variance'] for m in models]
 ax[0,1].bar(np.arange(2)+(j-.5)*.32,vals,.30,label=f'{p} period'+('s' if p>1 else ''),color=[blue,teal][j])
ax[0,1].set_xticks(range(2),labels,fontsize=8);ax[0,1].set_ylabel('Paired occupation variance');ax[0,1].legend(frameon=False,fontsize=8);ax[0,1].set_title('B  Longer integration reduces variance',loc='left',weight='bold',fontsize=10)
for p,color in [(1,blue),(4,teal)]:
 rows=sorted([r for r in power if r['model']==models[1] and r['periods']==p and r['mixture']==0 and r['tolerance']==0],key=lambda r:r['horizon'])
 y=np.array([r['estimate'] for r in rows]);err=np.array([[r['pointwise_95'][0],r['pointwise_95'][1]] for r in rows])
 ax[1,0].errorbar([r['horizon']*p for r in rows],y,yerr=[y-err[:,0],err[:,1]-y],fmt='o-',color=color,label=f'{p} period'+('s' if p>1 else ''),capsize=3)
ax[1,0].set_xscale('log',base=2);ax[1,0].set_xlabel('Accumulated periods per arm');ax[1,0].set_ylabel('Crossing probability');ax[1,0].set_ylim(0,1.03);ax[1,0].legend(frameon=False,fontsize=8);ax[1,0].set_title('C  Compare acquisition cost as well',loc='left',weight='bold',fontsize=10)
for mix,color in [(0,blue),(1,red)]:
 rows=sorted([r for r in power if r['model']==models[1] and r['periods']==4 and r['mixture']==mix and r['horizon']==8192],key=lambda r:r['tolerance'])
 y=np.array([r['estimate'] for r in rows]);lo=np.array([r['pointwise_95'][0] for r in rows]);hi=np.array([r['pointwise_95'][1] for r in rows])
 ax[1,1].errorbar([r['tolerance'] for r in rows],y,yerr=[y-lo,hi-y],fmt='o-',color=color,label=['Four stakes','Six stakes'][mix],capsize=3)
ax[1,1].set_xlabel('Conditional mean tolerance');ax[1,1].set_ylabel('Crossing probability');ax[1,1].set_ylim(0,1.03);ax[1,1].legend(frameon=False,fontsize=8);ax[1,1].set_title('D  Calibration consumes power',loc='left',weight='bold',fontsize=10)
save(fig,'FIG14_trajectory_assay')
rows=list(csv.DictReader((D/'Data_S13_assay_calibration.csv').open()));ratewindows=[('1/8','1'),('1/8','4'),('1','1'),('1','4')];etas=['0','1/100','1/20','1/10']
fig,axes=plt.subplots(1,2,figsize=(8,4),layout='constrained')
for ax,endpoint,title in zip(axes,['0','1/100'],['A  Exact endpoints','B  Endpoint error bound 0.01']):
 values=[]
 for gamma,periods in ratewindows:
  line=[]
  for eta in etas:
   r=next(r for r in rows if r['gamma']==gamma and r['periods']==periods and r['relative_rate_error']==eta and r['endpoint_error']==endpoint)
   b=F(r['bias_allowance']);d=F(r['guaranteed_gap'])+2*b;line.append(float(2*b/d))
  values.append(line)
 colors=np.array(values)<1
 ax.imshow(colors,cmap=matplotlib.colors.ListedColormap(['#F3DFEC','#EAE4F5']),vmin=0,vmax=1,aspect='auto')
 for i in range(4):
  for j in range(4):ax.text(j,i,f'{values[i][j]:.2f}',ha='center',va='center',color=gray)
 ax.set_xticks(range(4),['0%','1%','5%','10%']);ax.set_yticks(range(4),['slow, 1 period','slow, 4 periods','fast, 1 period','fast, 4 periods'],fontsize=8);ax.set_xlabel('Relative rate uncertainty');ax.set_title(title,loc='left',fontsize=10,weight='bold')
fig.suptitle('Bias-to-margin ratio 2b / D: green cells retain a positive guaranteed gap',fontsize=10)
save(fig,'FIG15_calibration_budget')
# Unnumbered initial visual abstract. All numeric claims come from the certificates.
fig,ax=plt.subplots(figsize=(8.8,8.0));fig.subplots_adjust(.02,.02,.98,.98);ax.set_xlim(0,12);ax.set_ylim(0,12);ax.axis('off')
def box(x,y,w,h,title,body,color=blue):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.10',facecolor='#f4f8fa',edgecolor=color,lw=1.25))
 ax.text(x+.22,y+h-.35,title,fontsize=12,weight='bold',color=color,va='top')
 if body:ax.text(x+.22,y+h-.95,body,fontsize=10,color=gray,va='top',linespacing=1.55)
def arrow(a,b):ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=15,color=gray,lw=1.3))
box(.2,8.9,11.6,2.7,'1  Balance the input, preserve temporal order','24 pulses per period   |   equal dose and cyclic word counts through length 7')
words=['101111110010110010001000','100010110010111111001000']
for k,w in enumerate(words):
 y=9.7-k*.48;ax.text(.5,y+.12,'a' if k==0 else 'b',weight='bold',fontsize=12)
 for j,z in enumerate(w):ax.add_patch(Rectangle((1.1+j*.42,y),.39,.28,facecolor=blue if z=='1' else '#dbe4e9',edgecolor='none'))
box(.2,5.6,5.45,2.65,'2  A class-wide null','Positive two-state kinetics\nPeriodic integrated contrast = 0\nUniform over the kinetic parameters',blue)
box(6.15,5.6,5.65,2.65,'A certified separator','Positive three-state construction\nIntegrated contrast > 0.01007\nIndependently certified rate neighborhood',teal)
arrow((3,8.85),(3,8.30));arrow((9,8.85),(9,8.30))
box(.2,2.55,11.6,2.35,'3  Qualify the observation','Finite reporter windows can create or reverse a raw contrast.\nEndpoint correction recovers the integrated state observable.\nRate and endpoint uncertainty enter an explicit bias budget b.',blue)
arrow((3,5.5),(4,4.95));arrow((9,5.5),(8,4.95))
box(.2,.15,11.6,1.75,'4  Test the qualified contrast','Predictable tolerance + bounded score → sequential evidence\nChoose acquisition time, block count and precision jointly.',teal)
arrow((6,2.45),(6,2.0))
save(fig,'VISUAL_ABSTRACT')
g=json.loads(json.dumps(runpy.run_path(str(R/'visuals-v011/graph_model.py'))['graph']()))
new=[('trajectory','Continuous-time observation study','evidence','Independent moments and event-driven paths expose raw reporter transients and verify pathwise endpoint correction.'),('mcpower','Monte Carlo power with uncertainty','evidence','Frozen seeds and 512 experiments per setting; all 72 settings include pointwise and simultaneous intervals. Equal-time comparisons retained.'),('calibration','Calibration-aware endpoint budget','conditional','Coefficient and endpoint bounds give |X-X*| <= b, range 1+b, and guaranteed alternative gap D-2b.'),('assayplan','Prospective assay interfaces','conditional','Export paired FD7 stimulation plans and analyze qualified block scores. Biological calibration and device validation remain assay-specific.')]
for id,label,status,detail in new:g['nodes'].append(dict(id=id,label=label,layer=3,status=status,detail=detail,source='Main 3.14–3.15; SI S18–S20; Data S13'))
for a,b,k in [('designcert','trajectory','supports'),('reporterfinite','trajectory','supports'),('trajectory','mcpower','supports'),('poweraudit','mcpower','supports'),('reporterfinite','calibration','extends'),('calibration','assayplan','qualifies'),('mcpower','assayplan','informs'),('anytime','assayplan','supports')]:g['edges'].append(dict(source=a,target=b,kind=k))
g['version']='0.12';g['supplementary']='supplement-v012/SUPPLEMENTARY_INFORMATION.md';assert len(g['nodes'])==86 and len(g['edges'])==142
(G/'epistemic_graph.json').write_text(json.dumps(g,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
shell=(R/'visuals-v011/graph_shell.html').read_text(encoding='utf-8').replace('v0.11','v0.12').replace('82 nodes','86 nodes').replace('134 edges','142 edges')
(G/'epistemic_graph.html').write_text(shell.replace('__GRAPH_DATA__',json.dumps(g,ensure_ascii=False).replace('</','<\\/')),encoding='utf-8')
lines=['digraph ChronoWitness {']+[json.dumps(n['id'])+' [label='+json.dumps(n['label'])+'];' for n in g['nodes']]+[json.dumps(e['source'])+' -> '+json.dumps(e['target'])+' [label='+json.dumps(e['kind'])+'];' for e in g['edges']]
(G/'epistemic_graph.dot').write_text('\n'.join(lines+['}'])+'\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=list(D.glob('Data_S13*'))+[Path(__file__),R/'visuals-v011/graph_model.py',R/'visuals-v011/graph_shell.html']
outputs=[p for p in O.iterdir() if p.name!='FIGURE_PROVENANCE.json']+list(G.iterdir())
(O/'FIGURE_PROVENANCE.json').write_text(json.dumps(dict(status='VERIFIED_COMPUTATIONS_RENDERED',numbered_main_figures=13,supplementary_figures=3,visual_abstracts=1,inputs={p.relative_to(R).as_posix():sha(p) for p in inputs},outputs={p.relative_to(R).as_posix():sha(p) for p in outputs}),indent=2)+'\n')

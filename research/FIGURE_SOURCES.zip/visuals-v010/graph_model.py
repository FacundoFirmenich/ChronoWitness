"""Current scientific graph; earlier version files retain their original bytes."""
from pathlib import Path
import json,runpy
R=Path(__file__).resolve().parents[1]
def graph():
    old=runpy.run_path(str(R/'visuals-v09/graph_model.py'))['graph']()
    g=json.loads(json.dumps(old));removed={'noctmc','ctmcresearch'}
    g['nodes']=[n for n in g['nodes'] if n['id'] not in removed]
    g['edges']=[e for e in g['edges'] if e['source'] not in removed and e['target'] not in removed]
    byid={n['id']:n for n in g['nodes']}
    sources={
      'words':'Main 3.1; SI S2','runs':'Main 3.1; SI S2','symmetry':'Main 3.1; SI S2',
      'delivery':'Main 3.4 and 3.7; SI S6 and S11','phase':'Main 2.1; SI S1 and S3',
      'occupation':'Main 2.1; SI S1','detclass':'Main 2.1; SI S3','markovclass':'Main 2.1 and 3.2; SI S4',
      'kineticclass':'Main 3.4; Theorem 2; SI S6','linear':'Main 3.4; Theorem 2; SI S6.2',
      'mixture':'SI S6.2; reference 33','instrument':'Main 3.5; SI S7','det4':'Main 3.1; Result 1; SI S3',
      'criterion':'Main 3.2; Proposition 1; SI S4','markov3':'Main 3.3; SI S5',
      'margin':'Main 3.3; SI S5; Data S4','cascade':'Main 3.5; SI S7',
      'kineticnull':'Main 3.4; Theorem 2; SI S6.1','reporternull':'Main 3.4; Theorem 2; SI S6.2',
      'contraction':'SI S6.3','integration':'SI S6; Theorem 2','phaseadverse':'Main 3.1; SI S3.2; Figure S1',
      'nonembed':'Main 3.3; SI S5; reference 26','noagency':'Main Discussion; SI S8',
      'notpath':'Main 2.1 and Discussion; SI S1','nowashin':'SI S6.3','nonlinear':'Main 3.4; SI S6.2',
      'nobiology':'Main Methods and Data availability','qualify':'Main 3.6-3.9; SI S8 and S10-S13',
      'localize':'Main 3.5 and Discussion; SI S7-S8','qualifiedrejection':'Theorems 5-6; SI S12-S13',
      'literature':'Main Discussion and references; SI references','experiment':'SI S8 and S12'
    }
    for key,value in sources.items():byid[key]['source']=value
    byid['nonembed'].update(label='Discrete-kernel embedding obstruction',detail='The original discrete kernels have determinants -1/4 and zero. Their kinetic construction instead uses Q=2(P-I), with new valid pulse propagators; SI S15 certifies their integrated occupations.')
    byid['nobiology'].update(label='Theoretical and computational scope',detail='The evidence consists of declared mathematical designs, exact certificates and conditional model results. A biological assay would supply observations and calibration.')
    byid['noagency'].update(label='Scope of model attribution',detail='The test excludes a defined model-and-observation class. Identifying the responsible mechanism calls for additional interventions and measurement information.')
    byid['delivery']['detail']='ExposureBounds 4.16 supplies exposure certificates under its acquisition and clock conditions. The interface specifies the per-arm assumptions required for molecular readout bounds.'
    byid['literature']['detail']='Mechanistic memory, dynamic inputs, stochastic transcription, observation, model discrimination, embedding and uniformization provide the methodological context for these results.'
    def node(id,label,layer,status,detail,source):g['nodes'].append(dict(id=id,label=label,layer=layer,status=status,detail=detail,source=source))
    node('ctmccontract','Positive kinetic generators',1,'conditional','Common symbol-conditioned generators with strictly positive off-diagonal rates, equal pulse duration and full-period integrated occupations.','Main 3.11; SI S15.1')
    node('ctmc3','Continuous-time minimum: 3',2,'exact','Two states cannot separate the integrated occupations; explicit strictly positive three-state generators do. Rescaling gives a witness for any prescribed positive pulse duration.','Theorem 8; SI S15.1-S15.3')
    node('ctmcintegral','Exact integrated kinetic contrast',2,'exact','The state-zero occupation contrast is 13675244086935459 / (19104012816062696292530 log(2)), about 1.0327257952e-6 in the specified model.','Main 3.11; SI S15.3; Data S11')
    node('ctmcaudit','Independent uniformization certificate',3,'evidence','Rational spectral propagation and outward-rounded uniformization with a tree formula agree: 384 phase profiles, 144 operator-entry checks and 48 independent integrated coordinates.','SI S15.4 and S15.6; Data S11')
    node('ctmcrobust','Certified rate-perturbation neighborhood',2,'exact','Minorization controls invariant-row sensitivity. A maximum absolute row-sum perturbation of 1e-9 preserves a positive state-zero contrast above 1.0073311168e-6 in the stated rate units.','SI S15.5; Data S11')
    for a,b,k in [('fd7','ctmc3','instantiates'),('ctmccontract','ctmc3','requires'),('kineticnull','ctmc3','supports'),('ctmcintegral','ctmc3','supports'),('ctmcaudit','ctmcintegral','supports'),('ctmcaudit','ctmcrobust','supports'),('ctmcintegral','ctmcrobust','supports'),('ctmcrobust','ctmc3','supports'),('literature','ctmc3','contextualizes'),('ctmcintegral','localize','motivates'),('nonembed','ctmcintegral','distinguishes')]:g['edges'].append(dict(source=a,target=b,kind=k))
    g['version']='0.10';g['supplementary']='supplement-v010/SUPPLEMENTARY_INFORMATION.md'
    ids={n['id'] for n in g['nodes']};assert len(ids)==len(g['nodes'])==78
    assert all(e['source'] in ids and e['target'] in ids for e in g['edges'])
    assert len(g['edges'])==126
    return g

"""Render the exact kinetic certificate and updated scientific dependency map."""
from pathlib import Path
from fractions import Fraction as F
import csv,hashlib,json,math,textwrap
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'axes.edgecolor':'#263C68','xtick.color':'#263C68','ytick.color':'#263C68','grid.color':'#E1DDEF','axes.prop_cycle':matplotlib.cycler(color=['#356FA8','#7364B5','#B94C8C','#86A6D3'])})
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
from matplotlib.path import Path as DrawingPath
from graph_model import graph
R=Path(__file__).resolve().parents[1];O=R/'figures-v010';G=R/'graph-v010';D=R/'supplement-v010/data'
O.mkdir(exist_ok=True);G.mkdir(exist_ok=True)
certificate=json.loads((D/'Data_S11_kinetic_certificate.json').read_text())
with (D/'Data_S11_kinetic_curves.csv').open() as f:curves=list(csv.DictReader(f))
assert len(curves)==24
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
colors=['#166a83','#B94C8C','#654b91'];plotrows=[]
fig,ax=plt.subplots(3,1,figsize=(7.4,8.0),layout='constrained')
def value(r):return float(F(r['integral_constant']))/(24*int(r['duration_log2'])*math.log(2))+float(F(r['integral_log2']))/(24*int(r['duration_log2']))
base=[r for r in curves if r['duration_log2']=='1']
ax[0].bar(range(3),[value(r)*1e6 for r in base],color=colors);ax[0].axhline(0,color='#5a6471',lw=.8)
ax[0].set_xticks(range(3),['State 0','State 1','State 2']);ax[0].set_ylabel(r'Mean contrast ($10^{-6}$)');ax[0].set_title('A  Separation of continuously integrated occupations',loc='left',weight='bold')
for state,color in enumerate(colors):
    rs=[r for r in curves if int(r['state'])==state]
    ax[1].semilogy([int(r['duration_log2']) for r in rs],[abs(value(r)) for r in rs],'o-',ms=3,color=color,label=f'State {state}')
ax[1].set_xlabel('Pulse duration / log(2)');ax[1].set_ylabel('Absolute mean contrast');ax[1].legend(frameon=False,ncol=3,fontsize=8);ax[1].set_title('B  Exact duration dependence for the fixed generators',loc='left',weight='bold')
robust=certificate['rate_robustness'];bound=F(robust['lipschitz_upper']);dlo=F(certificate['normalized_state0_contrast'][0]);radius=dlo/bound
for j in range(101):
    eps=F(6*j,500)*radius;lower=dlo-bound*eps;plotrows.append((str(eps),str(lower)))
ax[2].plot([float(F(x))*1e8 for x,y in plotrows],[float(F(y))*1e6 for x,y in plotrows],color=colors[0],label='Certified lower bound')
ax[2].axhline(0,color='#5a6471',lw=.8);eps=F(robust['epsilon']);ax[2].plot(float(eps)*1e8,float(F(robust['contrast_lower']))*1e6,'o',color=colors[1],label=r'Radius $10^{-9}$')
ax[2].set_xlabel(r'Generator norm radius ($10^{-8}$)');ax[2].set_ylabel(r'Contrast lower bound ($10^{-6}$)');ax[2].legend(frameon=False,fontsize=8);ax[2].set_title('C  A quantified neighborhood preserves separation',loc='left',weight='bold')
for ext in ['pdf','svg','png']:fig.savefig(O/('FIG11_continuous_time.'+ext),dpi=180)
plt.close(fig)
with (O/'FIG11_plot_data.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['generator_norm_radius','certified_contrast_lower']);w.writerows(plotrows)
g=graph();(G/'epistemic_graph.json').write_text(json.dumps(g,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
html=(Path(__file__).parent/'graph_shell.html').read_text(encoding='utf-8').replace('__GRAPH_DATA__',json.dumps(g,ensure_ascii=False).replace('</','<\\/'))
(G/'epistemic_graph.html').write_text(html,encoding='utf-8')
lines=['digraph ChronoWitness {']+[json.dumps(n['id'])+' [label='+json.dumps(n['label'])+'];' for n in g['nodes']]+[json.dumps(e['source'])+' -> '+json.dumps(e['target'])+' [label='+json.dumps(e['kind'])+'];' for e in g['edges']]
(G/'epistemic_graph.dot').write_text('\n'.join(lines+['}'])+'\n')
fills={'exact':'#EAE4F5','conditional':'#B94C8C','adverse':'#F3DFEC','boundary':'#eee1f7','evidence':'#dbeaff','open':'#e7ebf1','separate':'#dceff4','context':'#e4edf8'}
byid={n['id']:n for n in g['nodes']}
main=[['fd7','phase','markovclass','ctmccontract'],['det4','markov3','kineticnull','ctmc3'],['enum','poly','integration','ctmcaudit'],['reporterfinite','deliverybound','saturationtransport','anytime']]
pos={id:(col*2.1,row*1.5) for row,ids in enumerate(main) for col,id in enumerate(ids)}
fig,ax=plt.subplots(figsize=(7.3,6.2),layout='constrained');ax.set_xlim(-.1,8.3);ax.set_ylim(6.1,-.5);ax.axis('off');patches={}
for id,(x,y) in pos.items():
    n=byid[id];patch=FancyBboxPatch((x,y),1.78,.79,boxstyle='round,pad=.04',facecolor=fills[n['status']],edgecolor='#5a6471',lw=.7,zorder=2);ax.add_patch(patch);patches[id]=patch
    ax.text(x+.89,y+.32,textwrap.fill(n['label'],22),ha='center',va='center',fontsize=8,zorder=3);ax.text(x+.89,y+.70,n['status'].upper(),ha='center',fontsize=5.7,color='#5a6471',zorder=3)
links=[('fd7','det4'),('phase','det4'),('markovclass','markov3'),('ctmccontract','ctmc3'),('enum','det4'),('poly','markov3'),('integration','kineticnull'),('kineticnull','ctmc3'),('ctmcaudit','ctmc3'),('kineticnull','reporterfinite'),('reporterfinite','deliverybound'),('deliverybound','saturationtransport'),('saturationtransport','anytime')]
for src,dst in links:
    if (src,dst)==('kineticnull','reporterfinite'):
        route=DrawingPath([(4.16,1.89),(4.0,1.89),(4.0,4.1),(.89,4.1),(.89,4.46)],[DrawingPath.MOVETO]+[DrawingPath.LINETO]*4)
        ax.add_patch(FancyArrowPatch(path=route,arrowstyle='-|>',mutation_scale=9,linewidth=1.1,color='#166a83',zorder=1))
        continue
    x,y=pos[src];u,v=pos[dst];ax.add_patch(FancyArrowPatch((x+.89,y+.39),(u+.89,v+.39),patchA=patches[src],patchB=patches[dst],arrowstyle='-|>',mutation_scale=9,linewidth=1.1,color='#166a83',connectionstyle='arc3,rad=.10',shrinkA=4,shrinkB=4,zorder=1))
ax.text(0,-.28,'Temporal design, state thresholds and observation-qualified inference',fontsize=9,color='#5a6471')
ax.text(0,5.78,'Selected logical dependencies; the interactive graph supplies all typed relations.\nArrows connect mathematical claims, conditions and verification.',fontsize=8,color='#5a6471')
for ext in ['pdf','svg','png']:fig.savefig(O/('FIG5_evidence_map.'+ext),dpi=180)
plt.close(fig)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=[p for p in Path(__file__).parent.iterdir() if p.is_file()]+list(D.glob('Data_S11*'))+[R/'visuals-v08/graph_model.py',R/'visuals-v09/graph_model.py']
outputs=[p for p in O.iterdir() if p.name!='FIGURE_PROVENANCE.json']+list(G.iterdir())
(O/'FIGURE_PROVENANCE.json').write_text(json.dumps(dict(status='CERTIFIED_KINETIC_DATA_RENDERED',total_main_figures=9,total_supplementary_figures=3,graph_nodes=len(g['nodes']),graph_edges=len(g['edges']),inputs={p.relative_to(R).as_posix():sha(p) for p in inputs},outputs={p.relative_to(R).as_posix():sha(p) for p in outputs}),indent=2)+'\n')

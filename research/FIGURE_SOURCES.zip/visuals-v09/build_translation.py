"""Render certified envelopes and the complete offline evidence graph."""
from pathlib import Path
from fractions import Fraction as F
import csv,hashlib,json,math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'axes.edgecolor':'#263C68','xtick.color':'#263C68','ytick.color':'#263C68','grid.color':'#E1DDEF','axes.prop_cycle':matplotlib.cycler(color=['#356FA8','#7364B5','#B94C8C','#86A6D3'])})
from graph_model import graph
R=Path(__file__).resolve().parents[1];O=R/'figures-v09';G=R/'graph-v09';D=R/'supplement-v09/data'
O.mkdir(exist_ok=True);G.mkdir(exist_ok=True)
with (D/'Data_S10_translation_curves.csv').open() as f:rows=list(csv.DictReader(f))
with (D/'Data_S10_translation_stationary.csv').open() as f:stationary=list(csv.DictReader(f))
assert len(rows)==64 and len(stationary)==81
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
fig,ax=plt.subplots(3,1,figsize=(7.4,8.1),layout='constrained')
x=[int(r['time_log2'])*math.log(2) for r in rows]
ax[0].semilogy(x,[float(F(r['protein_second_upper'])) for r in rows],color='#166a83',label='With degradation')
ax[0].semilogy(x,[float(F(r['deathfree_second_upper'])) for r in rows],color='#B94C8C',ls='--',label='Death-free upper envelope')
ax[0].axhline(8,color='#5a6471',lw=.8,ls=':',label='Stationary second moment 8')
ax[0].set_ylabel('Protein second moment');ax[0].set_xlabel('Time (declared rate units)');ax[0].set_title('A  Survival prevents indefinite accumulation',loc='left',weight='bold');ax[0].legend(frameon=False,fontsize=8)
for name,label,color in [('raw_arm_loss_upper','Raw average','#166a83'),('corrected_arm_loss_upper','Endpoint-corrected','#654b91')]:
    ax[1].plot(x,[float(F(r[name])) for r in rows],color=color,label=label)
ax[1].set_ylabel('Per-arm loss upper bound');ax[1].set_xlabel('Observation duration H (start = 0)');ax[1].set_title('B  Certified saturation distortion',loc='left',weight='bold');ax[1].legend(frameon=False,fontsize=8)
rr=[r for r in stationary if r['immigration']==r['mrna_degradation']==r['protein_degradation']=='1']
assert len(rr)==3 and all(F(r['protein_fano'])==1+F(r['translation'])/2 for r in rr)
ax[2].plot([float(F(r['translation'])) for r in rr],[float(F(r['protein_fano'])) for r in rr],'o-',color='#166a83',label='Explicit translation')
ax[2].axhline(1,color='#B94C8C',ls='--',label='Poisson replacement')
ax[2].set_ylabel('Stationary protein Fano factor');ax[2].set_xlabel('Translation rate k (g = d = 1)');ax[2].set_ylim(.8,2.2);ax[2].set_title('C  A shared mRNA lifetime increases protein variation',loc='left',weight='bold');ax[2].legend(frameon=False,fontsize=8)
for ext in ('pdf','svg','png'):fig.savefig(O/('FIG10_translation.'+ext),dpi=180)
plt.close(fig)
g=graph();(G/'epistemic_graph.json').write_text(json.dumps(g,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
html=(Path(__file__).parent/'graph_shell.html').read_text(encoding='utf-8').replace('__GRAPH_DATA__',json.dumps(g,ensure_ascii=False).replace('</','<\\/'))
(G/'epistemic_graph.html').write_text(html,encoding='utf-8')
lines=['digraph ChronoWitness {']+[json.dumps(n['id'])+' [label='+json.dumps(n['label'])+'];' for n in g['nodes']]+[json.dumps(e['source'])+' -> '+json.dumps(e['target'])+' [label='+json.dumps(e['kind'])+'];' for e in g['edges']]
(G/'epistemic_graph.dot').write_text('\n'.join(lines+['}'])+'\n',encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
inputs=[p for p in Path(__file__).parent.iterdir() if p.is_file()]+list(D.glob('Data_S10*'))
outputs=list(O.glob('FIG10*'))+list(G.iterdir())
(O/'FIGURE_PROVENANCE.json').write_text(json.dumps(dict(status='CERTIFIED_RATIONAL_DATA_RENDERED',biological_data=False,figures_added=1,total_main_figures=8,total_supplementary_figures=3,inputs={p.relative_to(R).as_posix():sha(p) for p in inputs},outputs={p.relative_to(R).as_posix():sha(p) for p in outputs}),indent=2)+'\n')

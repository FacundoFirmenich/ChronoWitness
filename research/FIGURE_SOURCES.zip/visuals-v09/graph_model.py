"""Extend the immutable evidence graph; historical dependencies retain provenance."""
from pathlib import Path
import runpy,json
R=Path(__file__).resolve().parents[1]
old=runpy.run_path(str(R/'visuals-v08/graph_model.py'))
node,edge=old['node'],old['edge']
node('translationcontract','Explicit translation rate bounds',1,'conditional','Predictable production upper bounds, degradation lower bounds and initial conditional second moments must hold before the block.','Supplementary Information S14.1')
node('translationmoments','Positive five-moment envelope',2,'exact','A Metzler comparison system bounds mRNA, protein, factorial second and cross moments without a burst approximation.','Theorem 7; Supplementary Information S14.2')
node('uniformtranslation','Degradation-aware uniform bound',2,'exact','A scaled positive equilibrium is a uniform supersolution. A death-free production envelope can grow quartically while this bound stays finite.','Supplementary Information S14.3')
node('translationaudit','Independent molecule-survival check',3,'evidence','2160 global moment identities and 3888 certified windows; ODE and cluster formulas share only the rational exponential-polynomial ring.','Supplementary Data S10; S14.5-S14.7')
node('translationpoisson','Equal-mean Poisson can underbound',4,'adverse','Catalytic translation creates correlated protein counts. At the declared stationary control, mean 2 gives second moment 8, while Poisson gives 6.','Supplementary Information S14.6')
node('translationtransport','Translation saturation budget',2,'exact','Moment envelopes bound average and endpoint losses. Both endpoint channels and the actual known reporter correction remain required.','Supplementary Information S14.4')
node('matrixuncertainty','Reporter-matrix uncertainty',5,'open','Production envelopes do not identify the actual correction matrix. Unknown coefficients and inaccessible endpoints require separate qualification.','Supplementary Information S14.4')
for a,b,k in [('translationcontract','translationmoments','requires'),('translationmoments','uniformtranslation','supports'),('translationaudit','translationmoments','supports'),('translationaudit','uniformtranslation','supports'),('translationmoments','translationtransport','supports'),('translationtransport','saturationtransport','supports'),('endpointaccess','translationtransport','requires'),('translationpoisson','translationmoments','motivates'),('countbranching','translationmoments','motivates'),('uniformtranslation','translationtransport','supports'),('matrixuncertainty','translationtransport','constrains'),('translationcontract','tailcalibration','requires'),('translationtransport','qualifiedrejection','supports')]:edge(a,b,k)
def graph():
    g=old['graph']();g['version']='0.9';g['supplementary']='supplement-v09/SUPPLEMENTARY_INFORMATION.md'
    assert len(g['nodes'])==75 and len(g['edges'])==118
    return g

from pathlib import Path
import json,gzip,csv,zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

H=Path(__file__).resolve().parent;O=H/'results';F=H/'figures';F.mkdir(exist_ok=True)
leaves=json.loads((O/'LEAF_CONTRASTS.json').read_text());summary=json.loads((O/'SUMMARY.json').read_text())
nodes=json.loads((O/'NODES.json').read_text());edges=json.loads((O/'EDGES.json').read_text())
with gzip.open(O/'NODE_METRICS.csv.gz','rt') as f:metrics=list(csv.DictReader(f))
P=json.loads((H/'PROTOCOL.json').read_text())
with zipfile.ZipFile((H/P['source']).resolve()) as z:rawrows=json.loads(z.read('results/LOCAL_METRICS.json'))
colors=['#2864C4','#8B5FBF','#C858AB'];ink='#20365D';pale='#C9D1E0';background='#F8F7FC'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'text.color':ink,'axes.labelcolor':ink,'xtick.color':ink,'ytick.color':ink,'axes.edgecolor':pale,'axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white','pdf.fonttype':42,'svg.fonttype':'none'})
g=[r for r in leaves if r['policy']=='local_gate' and r['joint_support']]
ad=[r for r in g if r['rmse_gain']<-.01]
case=lambda r:r['date']=='2022-04-15' and r['offset']==1 and r['horizon']==6
selected=[r for r in rawrows if case(r) and r['segment_start']==180 and r['edge']=='11' and r['band']=='middle']
rr={r['policy']:r for r in selected};fields=['mae','median_ae','rmse','q90_ae','q95_ae','tail05_mean']
values=[100*(1-rr['local_gate'][m]/rr['raw'][m]) for m in fields]
labels={'ES':['MAE','Mediana','RMSE','Cuantil 90','Cuantil 95','Cola 5%'],'EN':['MAE','Median','RMSE','90th quantile','95th quantile','Top 5% mean']}
for lang in ['ES','EN']:
 es=lang=='ES'
 fig=plt.figure(figsize=(8.4,8.5),layout='constrained');grid=fig.add_gridspec(2,2,height_ratios=[1.1,1]);axs=[fig.add_subplot(grid[0,0]),fig.add_subplot(grid[0,1]),fig.add_subplot(grid[1,:])]
 for hi,h in enumerate([6,12,24]):
  s=[r for r in g if r['horizon']==h]
  axs[0].scatter([100*r['mae_gain'] for r in s],[100*r['rmse_gain'] for r in s],s=24,c=colors[hi],alpha=.65,label=f'{h*5} min',edgecolors='white',linewidth=.35)
 axs[0].scatter([100*r['mae_gain'] for r in ad],[100*r['rmse_gain'] for r in ad],s=150,facecolors='none',edgecolors=ink,linewidths=1.2)
 for a in axs[:2]:a.axhline(0,color=ink,lw=.7);a.axvline(0,color=pale,lw=.6);a.grid(alpha=.15)
 axs[0].set(xlabel='Mejora MAE (%)' if es else 'MAE improvement (%)',ylabel='Mejora RMSE (%)' if es else 'RMSE improvement (%)',title='A · Error medio y cuadrático' if es else 'A · Absolute and quadratic error');axs[0].legend(frameon=False,fontsize=8)
 for hi,h in enumerate([6,12,24]):
  s=[r for r in g if r['horizon']==h]
  axs[1].scatter([100*r['mae_gain'] for r in s],[100*r['tail05_gain'] for r in s],s=24,c=colors[hi],alpha=.65,edgecolors='white',linewidth=.35)
 axs[1].set(xlabel='Mejora MAE (%)' if es else 'MAE improvement (%)',ylabel='Mejora de la cola 5% (%)' if es else 'Top-5% mean improvement (%)',title='B · Las colas conservan sus pérdidas' if es else 'B · Tail losses remain visible')
 y=np.arange(len(fields));axs[2].barh(y,values,color=[colors[0] if x>=0 else colors[2] for x in values],height=.65)
 axs[2].set_yticks(y,labels[lang]);axs[2].invert_yaxis();axs[2].axvline(0,color=ink,lw=.8)
 for i,v in enumerate(values):axs[2].text(v+(.3 if v>=0 else -.3),i,f'{v:+.2f}%',ha='left' if v>=0 else 'right',va='center',fontsize=9)
 axs[2].set_xlim(min(values)-5,max(values)+5)
 axs[2].set(xlabel='Mejora relativa (%)' if es else 'Relative improvement (%)',title='C · Caso adverso: 15 abr., 30 min' if es else 'C · Adverse case: Apr 15, 30 min')
 fig.suptitle('E5 · Mejoría típica y deterioros locales' if es else 'E5 · Typical improvement and local deterioration',fontsize=13,fontweight='bold')
 fig.get_layout_engine().set(rect=(0,.07,1,.94))
 fig.text(.5,.015,'270 jurisdicciones con soporte; horizontes y alineamientos comparten observaciones.\nC: segmento ≥180, entrada 11, banda intermedia, alineamiento principal.' if es else '270 supported jurisdictions; horizons and alignments share observations.\nC: segment ≥180, input 11, middle band, primary alignment.',ha='center',fontsize=7)
 for ext in ['pdf','svg','png']:fig.savefig(F/f'E5_ERROR_GEOMETRY_{lang}.{ext}',dpi=160)
 plt.close(fig)

 chosen=[n for n in nodes if case(n)];chosen_ids={n['node'] for n in chosen}
 m={r['node']:r for r in metrics if r['policy']=='local_gate' and r['domain']=='joint_support' and case(dict(r,date=r['date'],offset=int(r['offset']),horizon=int(r['horizon'])))}
 positions={}
 for depth in range(5):
  layer=[n for n in chosen if n['depth']==depth]
  for i,n in enumerate(layer):positions[n['node']]=((i+.5)/len(layer),4-depth)
 fig=plt.figure(figsize=(9.5,5.2));ax=fig.add_axes([.04,.22,.92,.67])
 edgecolors={'segment_start':colors[0],'edge':colors[1],'band':colors[2],'empty_intersection':pale}
 for e in edges:
  if e['parent'] not in chosen_ids:continue
  x1,y1=positions[e['parent']];x2,y2=positions[e['child']]
  ax.plot([x1,x2],[y1,y2],color=edgecolors[e['axis']],alpha=.18 if e['axis']!='empty_intersection' else .12,lw=.65,zorder=1)
 for n in chosen:
  node=n['node'];x,y=positions[node];r=m.get(node);nonempty=r is not None and int(r['n'])>0
  value=float(r['rmse_gain']) if nonempty else None
  color=colors[0] if value is not None and value>.01 else colors[2] if value is not None and value<-.01 else colors[1] if nonempty else 'white'
  ax.scatter([x],[y],s=100 if n['depth'] not in [0,4] else 160,c=[color],edgecolors=ink if nonempty else pale,linewidth=.6,zorder=4)
  if n['depth']==4:label='∅'
  elif n['depth']==0:label='Todo' if es else 'All'
  else:
   f=n['filters'];label='/'.join('*' if f[a] is None else str(f[a]) if a!='band' else {'low':'L','middle':'M','high':'H'}[f[a]] for a in ['segment_start','edge','band'])
  ax.text(x,y-.10,label,ha='center',va='top',rotation=90 if n['depth'] in [2,3] else 0,fontsize=7.3 if n['depth'] in [2,3] else 7)
 ax.set_xlim(-.01,1.01);ax.set_ylim(-.3,4.4);ax.set_xticks([]);ax.set_yticks(range(5),['∅','3','2','1','0']);ax.set_ylabel('Restricciones fijadas' if es else 'Fixed restrictions')
 for s in ax.spines.values():s.set_visible(False)
 legend=[Line2D([0],[0],marker='o',color='none',markerfacecolor=c,markeredgecolor=ink,label=l) for c,l in [(colors[0],'Mejora RMSE >1%' if es else 'RMSE gain >1%'),(colors[2],'Pérdida RMSE >1%' if es else 'RMSE loss >1%'),(colors[1],'Cambio ≤1%' if es else 'Change ≤1%'),('white','Sin hojas con soporte' if es else 'No supported leaves')]]
 fig.legend(handles=legend,loc='lower center',bbox_to_anchor=(.5,.10),ncol=4,frameon=False,fontsize=7)
 fig.suptitle('E5 · Inclusiones que conservan la jurisdicción local' if es else 'E5 · Set inclusions retain local jurisdictions',fontsize=12,fontweight='bold',y=.97)
 fig.text(.5,.925,'15 abril 2022 · horizonte 30 min · alineamiento principal · selección local · soporte común' if es else '15 April 2022 · 30-minute horizon · primary alignment · local selection · common support',ha='center',fontsize=7)
 fig.text(.5,.055,'Nodo = segmento / entrada / banda (L, M, H); * = conjunto mayor. 81 nodos, 220 inclusiones. Colores: RMSE; nodos dependientes.' if es else 'Node = segment / input / band (L, M, H); * = containing set. 81 nodes, 220 inclusions. Colors: RMSE; dependent nodes.',ha='center',fontsize=6.7)
 fig.text(.5,.025,'*/11/* mejora RMSE 1,04%; 180/11/M empeora 1,06%. ∅ es una intersección vacía del diseño.' if es else '*/11/* improves RMSE by 1.04%; 180/11/M deteriorates by 1.06%. ∅ is an empty design intersection.',ha='center',fontsize=7)
 for ext in ['pdf','svg','png']:fig.savefig(F/f'E5_INCLUSION_LATTICE_{lang}.{ext}',dpi=160)
 plt.close(fig)
(O/'FIGURE_BUILD.json').write_text(json.dumps({'matplotlib':matplotlib.__version__,'numpy':np.__version__,'languages':['es','en'],'figures':4,'source':'E4 saved measured-data summaries; no synthetic data'},indent=2))
print('PASS_FOUR_BILINGUAL_FIGURES')

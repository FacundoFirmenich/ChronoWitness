from pathlib import Path
from itertools import product
from collections import defaultdict,Counter
import csv,gzip,hashlib,json,math,zipfile,time

H=Path(__file__).resolve().parent
P=json.loads((H/'PROTOCOL.json').read_text(encoding='utf-8'))
OUT=H/'results'
AXES=list(P['refinement_axes'])
DOMAINS=P['support_domains'];POLICIES=P['policies']
EPS=[0.,.001,.01,.05]
def dump(name,x):
    (OUT/name).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def key(r):return (r['date'],r['offset'],r['horizon'])
def leaf(r):return tuple(r[a] for a in AXES)
def gain(x,base):return 0. if base==0 and x==0 else (None if base==0 else 1.-x/base)
def close(a,b):return math.isclose(a,b,rel_tol=2e-12,abs_tol=1e-8)

def main():
    start=time.monotonic();OUT.mkdir(exist_ok=False)
    archive=(H/P['source']).resolve();actual=hashlib.sha256(archive.read_bytes()).hexdigest()
    assert actual==P['source_sha256']
    frozen=json.loads((H/'FREEZE.json').read_text())
    for n,d in frozen['sha256'].items():assert hashlib.sha256((H/n).read_bytes()).hexdigest()==d,n
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        manifest=json.loads(z.read('SHA256.json'))
        for n,d in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==d,n
        rows=json.loads(z.read('results/LOCAL_METRICS.json'));global_rows=json.loads(z.read('results/GLOBAL_CONTEXT.json'))
    cases=sorted({key(r) for r in rows});assert len(cases)==18
    source={(key(r),leaf(r),r['policy']):r for r in rows}
    global_index={(key(r),r['policy']):r for r in global_rows}
    specs=list(product(*[[None]+P['refinement_axes'][a] for a in AXES]));assert len(specs)==80
    base_leaves=list(product(*[P['refinement_axes'][a] for a in AXES]))
    edge_specs=[]
    for i,s in enumerate(specs):
        for a,x in enumerate(s):
            if x is None:
                for v in P['refinement_axes'][AXES[a]]:
                    t=list(s);t[a]=v;edge_specs.append((i,specs.index(tuple(t)),AXES[a]))
    assert len(edge_specs)==184
    nodes=[];edges=[];allmetrics=[];allleaf=[];sens=[];roots=[]
    for ci,case in enumerate(cases):
        for l in base_leaves:
            b=source[(case,l,'raw')];g=source[(case,l,'local_gate')]
            if not b['support']['windows']:continue
            for policy in POLICIES:
                r=source[(case,l,policy)]
                allleaf.append(dict(date=case[0],offset=case[1],horizon=case[2],segment_start=l[0],edge=l[1],band=l[2],policy=policy,n=b['support']['windows'],evaluation_supported=b['support']['qualified'],joint_support=g['status']=='SUPPORTED',mae_gain=gain(r['mae'],b['mae']),rmse_gain=gain(r['rmse'],b['rmse']),tail05_gain=gain(r['tail05_mean'],b['tail05_mean'])))
        for si,spec in enumerate(specs):
            included=[l for l in base_leaves if all(v is None or l[a]==v for a,v in enumerate(spec))]
            node=f'C{ci:02d}N{si:02d}';depth=sum(x is not None for x in spec)
            nodes.append(dict(node=node,date=case[0],offset=case[1],horizon=case[2],depth=depth,filters=dict(zip(AXES,spec)),leaf_members=[list(l) for l in included]))
            for domain in DOMAINS:
                selected=[l for l in included if source[(case,l,'raw')]['support']['windows'] and (domain=='all_recorded' or (domain=='evaluation_supported' and source[(case,l,'raw')]['support']['qualified']) or (domain=='joint_support' and source[(case,l,'local_gate')]['status']=='SUPPORTED'))]
                weights=[source[(case,l,'raw')]['support']['windows'] for l in selected];n=sum(weights)
                base={m:(math.fsum(w*source[(case,l,'raw')][m] for l,w in zip(selected,weights))/n if n else None) for m in ['mae','bias']}
                base['mse']=math.fsum(w*source[(case,l,'raw')]['rmse']**2 for l,w in zip(selected,weights))/n if n else None
                for policy in POLICIES:
                    rr=[source[(case,l,policy)] for l in selected]
                    mm={m:(math.fsum(w*r[m] for r,w in zip(rr,weights))/n if n else None) for m in ['mae','bias']}
                    mm['mse']=math.fsum(w*r['rmse']**2 for r,w in zip(rr,weights))/n if n else None
                    if n:
                        mm['rmse']=math.sqrt(mm['mse']);gm=gain(mm['mae'],base['mae']);gr=gain(mm['rmse'],math.sqrt(base['mse']))
                        # Additive loss reduction, rather than an average of relative gains.
                        delta=math.fsum(w*(source[(case,l,'raw')]['mae']-r['mae']) for l,r,w in zip(selected,rr,weights))
                        assert close(delta,n*(base['mae']-mm['mae']))
                        if domain=='all_recorded' and depth==0:
                            expected=global_index[(case,policy)];assert n==expected['n']
                            for m in ['mae','rmse','bias']:assert close(mm[m],expected[m]),(case,policy,m)
                    else:mm['rmse']=None;gm=gr=None
                    joint=[l for l in selected if source[(case,l,'local_gate')]['status']=='SUPPORTED']
                    child={m:[gain(source[(case,l,policy)][m],source[(case,l,'raw')][m]) for l in joint] for m in ['mae','rmse','tail05_mean']}
                    child={m:[v for v in vals if v is not None] for m,vals in child.items()}
                    result=dict(node=node,date=case[0],offset=case[1],horizon=case[2],depth=depth,domain=domain,policy=policy,n=n,recorded_leaf_count=len(selected),supported_leaf_count=len(joint),mae=mm['mae'],rmse=mm['rmse'],bias=mm['bias'],raw_mae=base['mae'],raw_mse=base['mse'],mae_gain=gm,rmse_gain=gr,supported_mae_losses_1pct=sum(v<-.01 for v in child['mae']),supported_rmse_losses_1pct=sum(v<-.01 for v in child['rmse']),supported_tail_increases=sum(v<0 for v in child['tail05_mean']),tail_status='EMPTY' if not n else ('LEAF_EXACT' if depth==3 else ('ROOT_EXACT' if depth==0 and domain=='all_recorded' else 'NOT_RECOVERABLE_FROM_E4_SUMMARIES')))
                    allmetrics.append(result)
                    if depth<3 and n:
                        for eps in EPS:
                            sens.append(dict(node=node,case=ci,depth=depth,domain=domain,policy=policy,threshold=eps,mae_gain=gm,rmse_gain=gr,mae_mask=gm is not None and gm>eps and any(v< -eps for v in child['mae']),rmse_mask=gr is not None and gr>eps and any(v< -eps for v in child['rmse'])))
                    if depth==0 and domain=='all_recorded':
                        raw=global_index[(case,'raw')];p=global_index[(case,policy)]
                        roots.append(dict(**result,tail05_gain=gain(p['tail05_mean'],raw['tail05_mean'])))
        for parent,child,axis in edge_specs:edges.append(dict(parent=f'C{ci:02d}N{parent:02d}',child=f'C{ci:02d}N{child:02d}',axis=axis))
        bottom=f'C{ci:02d}EMPTY'
        nodes.append(dict(node=bottom,date=case[0],offset=case[1],horizon=case[2],depth=4,filters=None,leaf_members=[]))
        for si,spec in enumerate(specs):
            if all(v is not None for v in spec):edges.append(dict(parent=f'C{ci:02d}N{si:02d}',child=bottom,axis='empty_intersection'))
    assert len(nodes)==1458 and len(edges)==3960 and len(allmetrics)==30240
    dump('NODES.json',nodes);dump('EDGES.json',edges);dump('LEAF_CONTRASTS.json',allleaf);dump('ROOTS.json',roots)
    for name,records in [('NODE_METRICS.csv.gz',allmetrics),('MASKING_SENSITIVITY.csv.gz',sens)]:
        with gzip.open(OUT/name,'wt',encoding='utf-8',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
    summary=[]
    for policy in POLICIES:
        leaves=[r for r in allleaf if r['policy']==policy and r['joint_support']]
        parents=[r for r in allmetrics if r['policy']==policy and r['domain']=='joint_support' and r['depth']<3 and r['n']]
        masks=[r for r in sens if r['policy']==policy and r['domain']=='joint_support' and r['threshold']==.01]
        summary.append(dict(policy=policy,supported_leaves=len(leaves),leaf_mae_gain_1pct=sum(r['mae_gain']>.01 for r in leaves),leaf_mae_loss_1pct=sum(r['mae_gain']<-.01 for r in leaves),leaf_rmse_loss_1pct=sum(r['rmse_gain']<-.01 for r in leaves),leaf_tail_increase=sum(r['tail05_gain']<0 for r in leaves),nonempty_parent_nodes=len(parents),mae_masked_parent_nodes=sum(r['mae_mask'] for r in masks),rmse_masked_parent_nodes=sum(r['rmse_mask'] for r in masks),min_parent_mae_gain=min(r['mae_gain'] for r in parents),min_parent_rmse_gain=min(r['rmse_gain'] for r in parents)))
    gate_leaves=[r for r in allleaf if r['policy']=='local_gate' and r['joint_support']]
    assert len(gate_leaves)==270 and sum(r['tail05_gain']<0 for r in gate_leaves)==31
    adverse=[r for r in gate_leaves if r['tail05_gain']<0]
    pattern={a:dict(Counter(str(r[a]) for r in adverse)) for a in ['date','offset','horizon','segment_start','edge','band']}
    primary=[r for r in roots if r['policy']=='local_gate' and r['offset']==1 and r['horizon']==12]
    report=dict(status='COMPLETE_RETROSPECTIVE_E5_NESTED_AUDIT',nodes=len(nodes),inclusion_edges=len(edges),metric_rows=len(allmetrics),root_reconstruction_checks=18*7,source_sha256=actual,summary=summary,local_gate_tail_adversity_marginal_counts=pattern,primary_case_roots=primary,seconds=time.monotonic()-start,independent_replications=False,intermediate_pooled_tails_recovered=False,fisher_information_estimated=False)
    dump('SUMMARY.json',report)
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()

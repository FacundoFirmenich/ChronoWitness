from pathlib import Path
import argparse,json,gzip,runpy,hashlib,csv,io,math
H=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=H/'reproduced-results');args=parser.parse_args()
assert not args.output.exists(),'Choose a fresh output directory; reference results are never overwritten.'
ns=runpy.run_path(str(H/'audit.py'));ns['main'].__globals__['OUT']=args.output.resolve();ns['main']()
checked=[];differences=[];categorical=[]
float_fields={'mae','rmse','bias','raw_mae','raw_mse','mae_gain','rmse_gain','threshold'}
def compare(a,b,path):
 if isinstance(a,dict) and isinstance(b,dict):
  assert a.keys()==b.keys(),path
  for k in a:compare(a[k],b[k],path+'/'+str(k))
 elif isinstance(a,list) and isinstance(b,list):
  assert len(a)==len(b),path
  for i,(x,y) in enumerate(zip(a,b)):compare(x,y,path+'/'+str(i))
 elif isinstance(a,float) and isinstance(b,(float,int)):
  if a!=b:
   differences.append(dict(path=path,actual=a,expected=b,absolute_difference=abs(a-b)))
   if not math.isclose(a,b,rel_tol=2e-12,abs_tol=1e-8):categorical.append(dict(path=path,actual=a,expected=b,reason='NUMERIC_TOLERANCE_EXCEEDED'))
 elif a!=b:categorical.append(dict(path=path,actual=a,expected=b,reason='EXACT_FIELD_MISMATCH'))
for p in sorted(args.output.iterdir()):
 expected=H/'results'/p.name
 assert expected.is_file(),p.name
 if p.suffix=='.json':
  a=json.loads(p.read_text());b=json.loads(expected.read_text())
  if p.name=='SUMMARY.json':a={k:v for k,v in a.items() if k!='seconds'};b={k:v for k,v in b.items() if k!='seconds'}
  compare(a,b,p.name)
 elif p.suffix=='.gz':
  a=list(csv.DictReader(io.StringIO(gzip.decompress(p.read_bytes()).decode())));b=list(csv.DictReader(io.StringIO(gzip.decompress(expected.read_bytes()).decode())))
  for rr in [a,b]:
   for row in rr:
    for k in float_fields & row.keys():
     if row[k]!='':row[k]=float(row[k])
  compare(a,b,p.name)
 else:assert p.read_bytes()==expected.read_bytes(),p.name
 checked.append(p.name)
diagnostics=dict(float_differences=len(differences),max_absolute_difference=max([d['absolute_difference'] for d in differences],default=0),examples=differences[:20],categorical_or_excess_tolerance_mismatches=categorical,relative_tolerance=2e-12,absolute_tolerance=1e-8)
(args.output/'REPRODUCTION_DIFFERENCES.json').write_text(json.dumps(diagnostics,indent=2))
assert not categorical,diagnostics
receipt=dict(status='PASS_NUMERIC_E5_REPRODUCTION_EXACT_DISCRETE_FIELDS',files=checked,diagnostics=diagnostics,source_freeze=json.loads((H/'FREEZE.json').read_text()))
(args.output/'REPRODUCTION_RECEIPT.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))

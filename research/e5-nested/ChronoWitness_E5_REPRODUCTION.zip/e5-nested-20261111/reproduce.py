from pathlib import Path
import argparse,json,gzip,runpy,hashlib
H=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=H/'reproduced-results');args=parser.parse_args()
assert not args.output.exists(),'Choose a fresh output directory; reference results are never overwritten.'
ns=runpy.run_path(str(H/'audit.py'));ns['main'].__globals__['OUT']=args.output.resolve();ns['main']()
checked=[]
for p in sorted(args.output.iterdir()):
 expected=H/'results'/p.name
 assert expected.is_file(),p.name
 if p.suffix=='.json':
  a=json.loads(p.read_text());b=json.loads(expected.read_text())
  if p.name=='SUMMARY.json':a={k:v for k,v in a.items() if k!='seconds'};b={k:v for k,v in b.items() if k!='seconds'}
  assert a==b,p.name
 elif p.suffix=='.gz':
  assert gzip.decompress(p.read_bytes())==gzip.decompress(expected.read_bytes()),p.name
 else:assert p.read_bytes()==expected.read_bytes(),p.name
 checked.append(p.name)
receipt=dict(status='PASS_EXACT_E5_REPRODUCTION_EXCLUDING_RUNTIME_AND_GZIP_METADATA',files=checked,source_freeze=json.loads((H/'FREEZE.json').read_text()))
(args.output/'REPRODUCTION_RECEIPT.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt,indent=2))

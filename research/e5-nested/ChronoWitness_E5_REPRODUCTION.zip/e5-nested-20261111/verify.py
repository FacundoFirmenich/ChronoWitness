from pathlib import Path
import csv,gzip,json,zipfile,hashlib,math
import numpy as np

H=Path(__file__).resolve().parent;O=H/'results'
P=json.loads((H/'PROTOCOL.json').read_text());axes=list(P['refinement_axes'])
with zipfile.ZipFile((H/P['source']).resolve()) as z:rows=json.loads(z.read('results/LOCAL_METRICS.json'))
nodes=json.loads((O/'NODES.json').read_text());edges=json.loads((O/'EDGES.json').read_text())
idx={n['node']:n for n in nodes};case=lambda r:(r['date'],r['offset'],r['horizon'])
lk=lambda r:tuple(r[a] for a in axes)
source={(case(r),lk(r),r['policy']):r for r in rows}
with gzip.open(O/'NODE_METRICS.csv.gz','rt') as f:reported={(r['node'],r['domain'],r['policy']):r for r in csv.DictReader(f)}
with gzip.open(O/'MASKING_SENSITIVITY.csv.gz','rt') as f:masks={(r['node'],r['domain'],r['policy'],float(r['threshold'])):r for r in csv.DictReader(f)}
first=sorted({case(r) for r in rows})[0]
ns=[n for n in nodes if case(n)==first]
sets=[frozenset(tuple(x) for x in n['leaf_members']) for n in ns]
assert len(sets)==81 and len(set(sets))==81
setindex={s:i for i,s in enumerate(sets)}
pair_checks=0
for a in sets:
 for b in sets:
  assert a&b in setindex
  supers=[x for x in sets if a|b<=x]
  join=min(supers,key=len)
  assert all(join<=x for x in supers)
  pair_checks+=1
edgefirst=[e for e in edges if case(idx[e['parent']])==first]
for e in edgefirst:
 a=frozenset(tuple(x) for x in idx[e['parent']]['leaf_members']);b=frozenset(tuple(x) for x in idx[e['child']]['leaf_members'])
 assert b<a and not any(b<x<a for x in sets)
expected_covers=sum(1 for a in sets for b in sets if b<a and not any(b<x<a for x in sets))
assert len(edgefirst)==expected_covers==220
checks=0;max_error=0.;maskchecks=0
for c in sorted({case(r) for r in rows}):
 current=[n for n in nodes if case(n)==c]
 assert [frozenset(tuple(x) for x in n['leaf_members']) for n in current]==sets
 leaves=sorted({lk(r) for r in rows if case(r)==c})
 membership=np.array([[l in frozenset(tuple(x) for x in n['leaf_members']) for l in leaves] for n in current[:-1]],dtype=float)
 raw=[source[(c,l,'raw')] for l in leaves];gates=[source[(c,l,'local_gate')] for l in leaves]
 weights=np.array([r['support']['windows'] for r in raw],dtype=float)
 for domain in P['support_domains']:
  allowed=np.array([True if domain=='all_recorded' else r['support']['qualified'] if domain=='evaluation_supported' else g['status']=='SUPPORTED' for r,g in zip(raw,gates)])
  M=membership*(weights*allowed)[None,:];N=M.sum(axis=1)
  # Independent vectorized reconstruction from E4, not the audit's reported leaf table.
  R=np.array([[r.get('mae',0),r.get('rmse',0)**2,r.get('bias',0)] for r in raw]);rs=M@R
  for policy in P['policies']:
   p=[source[(c,l,policy)] for l in leaves]
   V=np.array([[r.get('mae',0),r.get('rmse',0)**2,r.get('bias',0)] for r in p]);ss=M@V
   for i,node in enumerate(current[:-1]):
    result=reported[(node['node'],domain,policy)];assert int(result['n'])==int(N[i])
    if not N[i]:assert result['mae']=='';continue
    got=ss[i]/N[i];base=rs[i]/N[i]
    for name,value in [('mae',got[0]),('rmse',np.sqrt(got[1])),('bias',got[2])]:
     error=abs(value-float(result[name]));max_error=max(max_error,float(error))
     assert np.isclose(value,float(result[name]),rtol=2e-12,atol=1e-8),(node['node'],domain,policy,name)
    checks+=1
    if node['depth']<3:
     selected=[j for j,l in enumerate(leaves) if membership[i,j] and allowed[j] and gates[j]['status']=='SUPPORTED' and weights[j]>0]
     parent_gains={'mae':1-got[0]/base[0],'rmse':1-np.sqrt(got[1]/base[1])}
     for eps in [0.,.001,.01,.05]:
      m=masks[(node['node'],domain,policy,eps)]
      for metric in ['mae','rmse']:
       adverse=any(1-p[j][metric]/raw[j][metric]<-eps for j in selected)
       expected=parent_gains[metric]>eps and adverse
       # At epsilon zero, roundoff can affect an exactly tied parent; use direct sums.
       if eps==0 and abs(parent_gains[metric])<1e-12:continue
       assert expected==(m[metric+'_mask']=='True'),(node['node'],policy,metric,eps)
       maskchecks+=1
report=dict(status='PASS_INDEPENDENT_VECTORIZED_RECONSTRUCTION_AND_SET_LATTICE',nonempty_metric_rows_checked=checks,mask_decisions_checked=maskchecks,metric_max_absolute_difference=max_error,structural_pair_checks=pair_checks,covers_per_case=expected_covers,nodes_per_case=81,code_freeze_unchanged=True)
freeze=json.loads((H/'FREEZE.json').read_text())
for n,h in freeze['sha256'].items():assert hashlib.sha256((H/n).read_bytes()).hexdigest()==h
(O/'INDEPENDENT_VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

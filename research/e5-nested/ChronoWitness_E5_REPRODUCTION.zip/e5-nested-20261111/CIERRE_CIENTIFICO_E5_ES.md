# Cierre científico E5: localidad anidada y ocultamiento por agregación

La posición del proyecto mejora: la interpretación local de E4 ahora tiene una reconstrucción explícita y verificada de sus relaciones entre escalas. E5 conserva conjuntos mayores, intersecciones, soporte y resultados adversos, sin sustituir las jurisdicciones por un indicador general ni alterar los resultados anteriores.

## Resultado sustantivo

La selección local no presenta deterioro continuo de MAE en las 270 jurisdicciones con soporte común. E5 demuestra y comprueba que esa propiedad se conserva en los 544 conjuntos mayores no vacíos de la familia examinada. La explicación es aditiva: la diferencia de pérdidas del conjunto es la suma ponderada de las diferencias locales. No se trata de que ganancias grandes estén compensando pérdidas locales de MAE dentro de este soporte.

Esta consistencia no se extiende automáticamente a RMSE. La auditoría localiza dos deterioros de RMSE superiores al 1% y dos agrupaciones favorables que los ocultan. Ambos deterioros corresponden a una misma configuración bajo dos alineamientos relacionados: experimento 2022-04-15, horizonte de 30 minutos, segmento desde el origen 180, entrada 11 y fluorescencia intermedia. No son dos replicaciones independientes.

En el alineamiento principal, la selección afín temprana lleva el MAE de 237,49 a 229,80 (mejora del 3,24%) y la mediana del error absoluto de 164,00 a 141,56. Sin embargo, RMSE pasa de 371,83 a 375,77 (deterioro del 1,06%), el cuantil 95 de 766,54 a 797,77, y la media de la cola superior del 5% de 1225,16 a 1256,94 (deterioro del 2,59%). El sesgo firmado pasa de +22,35 a −56,10. La mejora del error típico coexiste con deterioro de errores grandes.

Al reunir los segmentos y bandas de la entrada 11 sobre el mismo soporte común, el RMSE mejora un 1,04%. Es un ejemplo real de ocultamiento por agregación del mismo criterio; no depende de asumir gaussianidad. Los 31 deterioros de cola identificados en E4 siguen registrados.

## Comparación sobre el mismo soporte

| Política | Pérdidas locales MAE >1% | Padres MAE favorables con pérdidas locales | Pérdidas locales RMSE >1% | Padres RMSE favorables con pérdidas locales |
|---|---:|---:|---:|---:|
| Offset global | 56 | 51 | 51 | 42 |
| Afín global | 57 | 15 | 42 | 8 |
| Selección global E3 | 3 | 15 | 6 | 5 |
| Offset local | 80 | 50 | 34 | 55 |
| Afín local | 75 | 36 | 14 | 16 |
| Mezcla local fija | 41 | 32 | 1 | 0 |
| Selección local | 0 | 0 | 2 | 2 |

Los 544 padres comparten hojas; sus recuentos describen ocultamiento en una familia de conjuntos, no 544 experimentos independientes. Las comparaciones retienen los valores continuos y sensibilidades a 0%, 0,1%, 1% y 5%. Los contrastes de RMSE cercanos al 1% no se convierten en significación ni en un umbral biológico.

## Arquitectura y verificación

La familia contiene 81 nodos y 220 inclusiones inmediatas por caso, incluidos el conjunto total y el vacío estructural. Hay 18 casos separados: 1458 nodos y 3960 aristas. Las aristas son inclusiones entre conjuntos del diseño, no conexiones moleculares. El supremo es el menor conjunto representado que contiene a ambos nodos y puede exceder su unión literal.

Se conservan 30240 filas métricas, incluidas las vacías. Una implementación vectorizada separada verificó las 24528 no vacías, con diferencia máxima 2,28×10⁻¹³, además de las decisiones de ocultamiento comprobables fuera del empate numérico al umbral cero. Se verificaron 6561 pares estructurales, la existencia de intersecciones y supremos y las relaciones de cobertura. Las fuentes y el código principal se mantuvieron congelados. El análisis principal tardó aproximadamente 3,83 segundos localmente, utilizando solamente los resúmenes guardados de E4.

## Alcance, reparabilidad y próxima decisión

E5 es una auditoría retrospectiva, especificada después de conocer E4. No introduce una nueva cohorte ni una intervención celular FD7. Tampoco estima información de Fisher o una resolución multiescalar universal. Los cuantiles y colas agrupados de nodos intermedios no se pueden determinar exactamente a partir de estos resúmenes; permanecen marcados como no recuperables, sin promediar colas locales para aparentar una medición nueva.

El deterioro localizado es reparable como problema de diseño futuro: la selección temprana puede contrastarse con reglas que consideren simultáneamente error típico y grandes errores. Esa regla necesitaría un protocolo separado y validación temporal propia; el resultado actual no autoriza corregir retrospectivamente la decisión E4 ni prometer que un nuevo filtro eliminará pérdidas futuras.

Para el objetivo del preprint, E5 fortalece el análisis de jurisdicciones y da un ejemplo numérico trazable de ocultamiento por agregación. Se incorpora como sección 3.17 del manuscrito y S25 del suplemento, con figuras castellanas e inglesas, preservando los teoremas FD7 y su observable de media periódica. La siguiente decisión científica es si merece una campaña distinta de selección sensible a colas; E5 queda completo sin necesitarla para sostener sus resultados.
